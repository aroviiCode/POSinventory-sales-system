/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package posinventory;


import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Vector;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.Timer;
import java.util.Date;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
/**
 *
 * @author john paul
 */
public class sale extends javax.swing.JPanel {
    
    Connection con = null;
    ResultSet rs = null;
    PreparedStatement pst = null;

    public static String barcode_c = "0" ;
    public static String cus_id = "0";
    public static String ss_eid = "0";
    
    public  Integer stck_qty = 0;
    
     //String id = "0";
    
    public sale() {
        initComponents();
        data_load();
        br_code.requestFocus(true);
        
        con = db.mycon();
        
        
        
        
        //loadcart();
    }

    public void data_load(){
        
        
        // load customer
  
      try {
          
          Statement s= db.mycon().createStatement();
          
          ResultSet rs = s.executeQuery("SELECT * FROM customer");
          Vector v = new Vector();
          
          while (rs.next()) {              
              v.add(rs.getString("customer_name"));
              
              DefaultComboBoxModel com = new DefaultComboBoxModel(v);
              com_cus.setModel(com);
               
          }
           
      } catch (SQLException e) {
            System.out.println(e);
      }
      
    // load employee
  
      try {
          
          Statement s= db.mycon().createStatement();
          
          ResultSet rs = s.executeQuery("SELECT * FROM employee");
          Vector v = new Vector();
          
          while (rs.next()) {              
              v.add(rs.getString("employee_name"));
              
              DefaultComboBoxModel com = new DefaultComboBoxModel(v);
              s_employee.setModel(com);
               
          }
           
      } catch (SQLException e) {
            System.out.println(e);
      }
      

    // load Product
  
     /* try {
          
          Statement s= db.mycon().createStatement();
          
          ResultSet rs = s.executeQuery("SELECT * FROM product");
          Vector v = new Vector();
          
          while (rs.next()) {              
              v.add(rs.getString("Product_Name"));
              
              DefaultComboBoxModel com = new DefaultComboBoxModel(v);
              com_pro.setModel(com);
               
          }
           
      } catch (SQLException e) {
            System.out.println(e);
      }  
      */
      // load last invoice number
      
      try {
          
        Statement s = db.mycon().createStatement();
          ResultSet rs = s.executeQuery("SELECT * FROM extra WHERE exid =1");
          
          if (rs.next()) {
              
              inid.setText(rs.getString("val"));
              
          }
          
      } catch (Exception e) {
      }
     
      // plus new invoice
      int i = Integer.valueOf(inid.getText());
      i++;
      inid.setText(String.valueOf(i));
      
      
     
      
  }
  
  public void pro_tot_cal(){
 
  // product calculation
         
        int qt = Integer.valueOf(p_qty.getText());
        Double price = Double.valueOf(u_price.getText());
        Double tot ;
        
        tot = qt * price;
        
        tot_price.setText(String.valueOf(tot));
 
 }   
  
  public void cart_total(){
 
 int numofrow = s_tbl.getRowCount();
 
    double total = 0;
    
     for (int i = 0; i < numofrow; i++) {
         
         double value = Double.valueOf(s_tbl.getValueAt(i, 5).toString());
         total += value ;
     }
    bill_tot.setText(Double.toString(total));
    
   /// total qty count 
   
   int numofrows = s_tbl.getRowCount();
 
    double totals = 0;
    
     for (int i = 0; i < numofrows; i++) {
         
         double values = Double.valueOf(s_tbl   .getValueAt(i, 3).toString());
         totals += values ;
     }
    tot_qty.setText(Double.toString(totals));
    
 
 
 
 }
 
  public void tot(){
     
 Double paid = Double.valueOf(paid_amt.getText());
       Double tot = Double.valueOf(bill_tot.getText());
       Double due ;
       
       due =  paid -tot ;
       
       balance.setText(String.valueOf(due));
 
 }
  
  public void stckup(){
   // get all table product id and sell qty
   
   DefaultTableModel dt = (DefaultTableModel) s_tbl.getModel();
   int rc = dt.getRowCount();
   
   for (int i = 0; i < rc; i++) {
       
       String br2_code = dt.getValueAt (i, 2).toString(); //id pr barcode
       String sell_qty = dt.getValueAt(i, 3).toString(); // ID OR BARCODE
       
       System.out.println(br2_code);
       System.out.println(sell_qty);
       
       try {
           
           Statement s = db.mycon().createStatement();
           ResultSet rs = s.executeQuery("SELECT qty FROM product WHERE bar_code = '"+br2_code+"'");
           
           if (rs.next ()){
             
               stck_qty = Integer.valueOf(rs.getString("qty"));
               
           }
       } catch (Exception e){
           System.out.println(e);
       }
       
       Integer st_qty = stck_qty;
       Integer sel_qty = Integer.valueOf (sell_qty);
       
       Integer new_qty = st_qty + sel_qty; // new qty = stock qty - sell qty
       
        String nqty = String.valueOf(new_qty);
        
         try {
             
            Statement ss = db.mycon().createStatement();
             ss.executeUpdate("UPDATE product SET qty ='"+nqty+"' WHERE bar_code ='"+br2_code+"'   ");
             // update new qty in product table 
             
             
             
         } catch (Exception e) {
             System.out.println(e);
         }
   }
  }
  
  
public void plus()
    {    
        
        try {
        
       Statement ss = db.mycon().createStatement();
       ss.executeUpdate("UPDATE product SET qty = qty+ '"+p_qty.getText()+"' WHERE bar_code ='" +br_code.getText()+ "'");   
       
       /*DefaultTableModel dt = (DefaultTableModel) s_tbl.getModel();
       dt.setRowCount(0);*/
       //data_load(); 
      /* pst.executeUpdate();
       updateDB();
       pst.close();*/
       
       
        } catch (SQLException ex) {
            Logger.getLogger(sale.class.getName()).log(Level.SEVERE, null, ex);
            
        }
    }
    
   
   
  
   public void minus()
    {         
        try {
       Statement ss = db.mycon().createStatement();
       ss.executeUpdate("UPDATE product SET qty = qty- '"+p_qty.getText()+"' WHERE bar_code ='" +br_code.getText()+ "'");   
       
       /*DefaultTableModel dt = (DefaultTableModel) s_tbl.getModel();
       dt.setRowCount(0);  
       data_load();
       /*pst.executeUpdate();
       updateDB();
       pst.close();*/
       
        } catch (SQLException ex) {
            Logger.getLogger(sale.class.getName()).log(Level.SEVERE, null, ex);                
        }      
    }

    /**
     *
     */
    public void stckvoid(){
   // get all table product id and sell qty
   
   DefaultTableModel dt = (DefaultTableModel) s_tbl.getModel();
   int rc = dt.getRowCount();
   
   for (int i = 0; i < rc; i++) {
       
       String br2_code = dt.getValueAt (i, 2).toString(); //id pr barcode
       String sell_qty = dt.getValueAt(i, 3).toString(); // ID OR BARCODE
       
       System.out.println(br2_code);
       System.out.println(sell_qty);
       
       try {
           
           Statement s = db.mycon().createStatement();
           ResultSet rs = s.executeQuery("SELECT qty FROM product WHERE bar_code = '"+br2_code+"'");
           
           if (rs.next ()){
             
               stck_qty = Integer.valueOf(rs.getString("qty"));
               
           }
       } catch (Exception e){
           System.out.println(e);
       }
       
       
       Integer st_qty = stck_qty;
       Integer sel_qty = Integer.valueOf (sell_qty);
       
       Integer new_qty = st_qty + sel_qty; // new qty = stock qty + sell qty
       
        String nqty = String.valueOf(new_qty);
        
         try {
             
            Statement ss = db.mycon().createStatement();
             ss.executeUpdate("UPDATE product SET qty ='"+nqty+"' WHERE bar_code ='"+br2_code+"'   ");
             // update new qty in product table 
             
             
             
         } catch (Exception e) {
             System.out.println(e);
         }
   }
  }
    public void stck_qty(){
        
            String  brcode =br_code.getText();
        try {
            
            Statement s = db.mycon().createStatement();
            ResultSet rs = s.executeQuery("SELECT qty FROM product WHERE bar_code ='"+brcode+"'  ");
           if (rs.next()) {
                
                l_stqty.setText(rs.getString("qty"));
             
                
                
            }
            
            
        } catch (SQLException e) {
            System.out.println(e);
        }
    }                    
  
public void loadcart(){
    
    try {
        int q;
        
        
        
        pst = con.prepareStatement ("SELECT * FROM cart");
        rs = pst.executeQuery();
        
        ResultSetMetaData rss = rs.getMetaData();
        q = rss.getColumnCount();
        
        DefaultTableModel dt = (DefaultTableModel) s_tbl.getModel();
        dt.setRowCount(0);
        
        while(rs.next()){
            
            Vector v = new Vector();
            
              
            for(int a = 1; a <= q; a++){
                v.add(rs.getString("bar_code"));
                v.add(rs.getString("bar_code"));
                v.add(rs.getString("bar_code"));
                v.add(rs.getString("bar_code"));
            }
            dt.addRow(v);
        }
    }catch(Exception e){
    }
}
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel14 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        inid = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        s_employee = new javax.swing.JComboBox<>();
        s_eidd = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        u_price = new javax.swing.JLabel();
        p_qty = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        tot_price = new javax.swing.JLabel();
        br_code = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        l_stqty = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        dcart_btn = new javax.swing.JButton();
        com_pro = new javax.swing.JTextField();
        jPanel4 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        s_tbl = new javax.swing.JTable();
        jPanel5 = new javax.swing.JPanel();
        rmv_btn = new javax.swing.JButton();
        rmv_all_btn = new javax.swing.JButton();
        jPanel6 = new javax.swing.JPanel();
        paid_amt = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jPanel7 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        bill_tot = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        balance = new javax.swing.JLabel();
        tot_qty = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        com_cus = new javax.swing.JComboBox<>();
        cus_qty = new javax.swing.JLabel();
        lbl_cid = new javax.swing.JLabel();
        b_pay = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();

        jLabel14.setText("jLabel14");

        jPanel1.setBackground(new java.awt.Color(180, 205, 230));

        jPanel2.setBackground(new java.awt.Color(162, 179, 139));
        jPanel2.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        inid.setFont(new java.awt.Font("Tahoma", 1, 30)); // NOI18N
        inid.setForeground(new java.awt.Color(51, 51, 51));
        inid.setText("01");

        jLabel3.setBackground(new java.awt.Color(204, 204, 204));
        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(51, 51, 51));

        s_employee.setEditable(true);
        s_employee.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        s_employee.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select" }));
        s_employee.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                s_employeeActionPerformed(evt);
            }
        });
        s_employee.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                s_employeeKeyReleased(evt);
            }
        });

        s_eidd.setBackground(new java.awt.Color(204, 204, 204));
        s_eidd.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        s_eidd.setForeground(new java.awt.Color(51, 51, 51));
        s_eidd.setText("0");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(inid, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel3)
                .addGap(38, 38, 38)
                .addComponent(s_employee, javax.swing.GroupLayout.PREFERRED_SIZE, 290, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(s_eidd, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(inid, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(s_employee, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(s_eidd, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, Short.MAX_VALUE))
        );

        jPanel3.setBackground(new java.awt.Color(162, 179, 139));
        jPanel3.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel4.setBackground(new java.awt.Color(204, 204, 204));
        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(51, 51, 51));
        jLabel4.setText("Product:");

        jLabel5.setBackground(new java.awt.Color(204, 204, 204));
        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(51, 51, 51));
        jLabel5.setText("Qty :");

        jLabel6.setBackground(new java.awt.Color(204, 204, 204));
        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(51, 51, 51));
        jLabel6.setText("Unit Price :");

        u_price.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        u_price.setForeground(new java.awt.Color(51, 51, 51));
        u_price.setText("00.00");

        p_qty.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        p_qty.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                p_qtyActionPerformed(evt);
            }
        });
        p_qty.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                p_qtyKeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                p_qtyKeyReleased(evt);
            }
        });

        jLabel7.setBackground(new java.awt.Color(204, 204, 204));
        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(51, 51, 51));
        jLabel7.setText("Total Price :");

        tot_price.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        tot_price.setForeground(new java.awt.Color(51, 51, 51));
        tot_price.setText("00.00");

        br_code.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        br_code.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                br_codeFocusGained(evt);
            }
        });
        br_code.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                br_codeActionPerformed(evt);
            }
        });
        br_code.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                br_codeKeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                br_codeKeyReleased(evt);
            }
        });

        jLabel13.setBackground(new java.awt.Color(204, 204, 204));
        jLabel13.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(51, 51, 51));
        jLabel13.setText("Barcode:");

        l_stqty.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        l_stqty.setForeground(new java.awt.Color(51, 51, 51));
        l_stqty.setText("00");

        jLabel12.setBackground(new java.awt.Color(204, 204, 204));
        jLabel12.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(51, 51, 51));
        jLabel12.setText("Stock Qty :");

        dcart_btn.setBackground(new java.awt.Color(0, 51, 51));
        dcart_btn.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        dcart_btn.setForeground(new java.awt.Color(204, 204, 204));
        dcart_btn.setText("Add to Cart");
        dcart_btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dcart_btnActionPerformed(evt);
            }
        });

        com_pro.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        com_pro.setForeground(new java.awt.Color(255, 51, 51));
        com_pro.setCaretColor(new java.awt.Color(102, 153, 0));
        com_pro.setSelectedTextColor(new java.awt.Color(204, 0, 0));
        com_pro.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                com_proFocusGained(evt);
            }
        });
        com_pro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                com_proActionPerformed(evt);
            }
        });
        com_pro.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                com_proKeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                com_proKeyReleased(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel13)
                        .addGap(7, 7, 7)))
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(br_code, javax.swing.GroupLayout.PREFERRED_SIZE, 287, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(com_pro, javax.swing.GroupLayout.PREFERRED_SIZE, 287, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(27, 27, 27)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel12)
                    .addComponent(jLabel5))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(l_stqty, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(p_qty, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 10, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel7)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(tot_price, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(7, 7, 7)
                        .addComponent(jLabel6)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(u_price, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(71, 71, 71)
                .addComponent(dcart_btn, javax.swing.GroupLayout.PREFERRED_SIZE, 193, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(57, 57, 57))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel13)
                            .addComponent(br_code, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel5)
                            .addComponent(p_qty, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel6)
                            .addComponent(u_price))
                        .addGap(13, 13, 13)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(jLabel7)
                            .addComponent(tot_price)
                            .addComponent(jLabel12)
                            .addComponent(l_stqty)
                            .addComponent(com_pro, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 9, Short.MAX_VALUE))
                    .addComponent(dcart_btn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        jPanel4.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        s_tbl.setBackground(new java.awt.Color(153, 153, 255));
        s_tbl.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        s_tbl.setForeground(new java.awt.Color(0, 51, 51));
        s_tbl.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "INID", "Name", "Bar code", "Qty", "Unit Price", "Total Price"
            }
        ));
        s_tbl.setGridColor(new java.awt.Color(0, 102, 102));
        s_tbl.setSelectionForeground(new java.awt.Color(204, 255, 204));
        s_tbl.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                s_tblMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(s_tbl);

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 808, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 2, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 234, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 7, Short.MAX_VALUE))
        );

        jPanel5.setBackground(new java.awt.Color(162, 179, 139));
        jPanel5.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        rmv_btn.setBackground(new java.awt.Color(0, 51, 51));
        rmv_btn.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        rmv_btn.setForeground(new java.awt.Color(204, 204, 204));
        rmv_btn.setText("Remove");
        rmv_btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rmv_btnActionPerformed(evt);
            }
        });

        rmv_all_btn.setBackground(new java.awt.Color(0, 51, 51));
        rmv_all_btn.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        rmv_all_btn.setForeground(new java.awt.Color(204, 204, 204));
        rmv_all_btn.setText("Void");
        rmv_all_btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rmv_all_btnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(rmv_btn, javax.swing.GroupLayout.DEFAULT_SIZE, 311, Short.MAX_VALUE)
            .addComponent(rmv_all_btn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(74, 74, 74)
                .addComponent(rmv_btn)
                .addGap(36, 36, 36)
                .addComponent(rmv_all_btn)
                .addContainerGap(77, Short.MAX_VALUE))
        );

        jPanel6.setBackground(new java.awt.Color(162, 179, 139));
        jPanel6.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        paid_amt.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        paid_amt.setText("0.0");
        paid_amt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                paid_amtActionPerformed(evt);
            }
        });
        paid_amt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                paid_amtKeyReleased(evt);
            }
        });

        jLabel8.setBackground(new java.awt.Color(204, 204, 204));
        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(51, 51, 51));
        jLabel8.setText("Paid Amount :");

        jPanel7.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        jLabel9.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel9.setText("Total Amount :");

        bill_tot.setBackground(new java.awt.Color(255, 255, 255));
        bill_tot.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        bill_tot.setForeground(new java.awt.Color(153, 153, 0));
        bill_tot.setText("00.00");
        bill_tot.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel11.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        jLabel11.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel11.setText("Balance/Change :");

        balance.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        balance.setText("00.00");
        balance.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(balance, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addGap(7, 7, 7)
                        .addComponent(bill_tot, javax.swing.GroupLayout.DEFAULT_SIZE, 111, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(bill_tot))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11)
                    .addComponent(balance))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        tot_qty.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        tot_qty.setForeground(new java.awt.Color(51, 51, 51));
        tot_qty.setText("00");

        jLabel10.setBackground(new java.awt.Color(204, 204, 204));
        jLabel10.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(51, 51, 51));
        jLabel10.setText("Total Qty :");

        jLabel1.setBackground(new java.awt.Color(204, 204, 204));
        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(51, 51, 51));
        jLabel1.setText("Customer :");

        com_cus.setEditable(true);
        com_cus.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        com_cus.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select" }));
        com_cus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                com_cusActionPerformed(evt);
            }
        });
        com_cus.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                com_cusKeyReleased(evt);
            }
        });

        cus_qty.setBackground(new java.awt.Color(204, 204, 204));
        cus_qty.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        cus_qty.setForeground(new java.awt.Color(51, 51, 51));
        cus_qty.setText("0");

        lbl_cid.setBackground(new java.awt.Color(204, 204, 204));
        lbl_cid.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        lbl_cid.setForeground(new java.awt.Color(51, 51, 51));
        lbl_cid.setText("0");

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addComponent(jLabel8)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(paid_amt, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel6Layout.createSequentialGroup()
                                .addComponent(cus_qty, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabel10)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(tot_qty, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(jPanel6Layout.createSequentialGroup()
                                .addComponent(com_cus, javax.swing.GroupLayout.PREFERRED_SIZE, 244, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lbl_cid, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap())
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(9, 9, 9))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel8)
                            .addComponent(paid_amt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel1)
                            .addComponent(com_cus, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lbl_cid, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tot_qty)
                            .addComponent(jLabel10)
                            .addComponent(cus_qty, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(20, 20, 20))))
        );

        b_pay.setBackground(new java.awt.Color(102, 102, 0));
        b_pay.setFont(new java.awt.Font("Tahoma", 1, 28)); // NOI18N
        b_pay.setForeground(new java.awt.Color(204, 204, 204));
        b_pay.setText("PAY & PRINT");
        b_pay.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b_payActionPerformed(evt);
            }
        });

        jLabel2.setText("Made by: The Burycats @CICT-SIC Department");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jPanel2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(b_pay, javax.swing.GroupLayout.DEFAULT_SIZE, 315, Short.MAX_VALUE))))
                .addGap(0, 10, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(jLabel2)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(34, 34, 34)
                        .addComponent(b_pay, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel2)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents

    private void p_qtyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_p_qtyActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_p_qtyActionPerformed

    private void dcart_btnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dcart_btnActionPerformed

        String bcode = String.valueOf(br_code.getText());
          if(bcode.isEmpty()){
             JOptionPane.showMessageDialog(null,"You still not choose any product yet."); 
          }
          else{
          
          //add  cart to product details 
        
      int sell_qty = Integer.valueOf(p_qty.getText());
      int stk_qty = Integer.valueOf(l_stqty.getText());
      
     if (sell_qty <= stk_qty && sell_qty != 0){
     
         DefaultTableModel dt = (DefaultTableModel) s_tbl.getModel();
        
        Vector v = new Vector();
        
        
        
        v.add(inid.getText()); // invoice id
        v.add(com_pro.getText()); // product name
        v.add(br_code.getText()); // barcode
        v.add(p_qty.getText()); // p qyt
        v.add(u_price.getText()); // unit price
        v.add(tot_price.getText()); // get total price
        
        dt.addRow(v);
        
        cart_total();
       tot(); 
       minus();
       stck_qty();
       
       try{
       Statement s = db.mycon().createStatement();
       ResultSet rs = s.executeQuery("SELECT qty FROM product WHERE bar_code = '"+br_code+"'");
       
       }catch(SQLException e){
           System.out.println(e);
                   
       }
         
     }
     else{
   
        JOptionPane.showMessageDialog(null, "Stock have " +stk_qty+ " quantity only.");
     
     }
        
          }  
       
        
    }//GEN-LAST:event_dcart_btnActionPerformed

    private void rmv_btnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rmv_btnActionPerformed
        // selected remove
        try {
            
            DefaultTableModel dt = (DefaultTableModel) s_tbl.getModel();
            int rw = s_tbl.getSelectedRow();
            dt.removeRow(rw);
           
            
        } catch (Exception e) {
            System.out.println(e);
        }
        cart_total(); 
        tot(); 
        plus();
        stck_qty();
        
    }//GEN-LAST:event_rmv_btnActionPerformed

    private void rmv_all_btnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rmv_all_btnActionPerformed
        // remove all
        
        //authenticate aut = new authenticate();
        //aut.setVisible(true);
        
        
        DefaultTableModel dt = (DefaultTableModel) s_tbl.getModel();
        stckup();
        dt.setRowCount(0);
        
        
        cart_total();
        tot(); 
    }//GEN-LAST:event_rmv_all_btnActionPerformed

    private void paid_amtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_paid_amtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_paid_amtActionPerformed

    private void b_payActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b_payActionPerformed
            

            int reply = JOptionPane.showConfirmDialog(null, "Are you sure you want to print this purchase?", "Warning", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
            if (reply == JOptionPane.YES_OPTION) {
            //know whether cust can debt
            
            
             int cqty = Integer.valueOf(cus_qty.getText());
             double billtot = Double.valueOf(bill_tot.getText());
             double c_blnc = Double.valueOf(balance.getText());
             //String pdmt = paid_amt.getText();
           
             if (billtot == 00.00){
                JOptionPane.showMessageDialog(null, "You do not have a purchase. Please choose atleast one.");  
             }
             if (cqty <= 5 && c_blnc < 0){
                JOptionPane.showMessageDialog(null, "Sorry, this customer is not yet legible for debt."); 
             }
            
             
             else{
             
          
        
        // data send to database
        
        try {
            
            // `cartid`, `INID`, `Product_Name`, `Bar_code`, `qty`, `Unit_Price`, `Total_Price`
            
          DefaultTableModel dt = (DefaultTableModel) s_tbl.getModel();
          int rc = dt.getRowCount();
          
            for (int i = 0; i < rc; i++) {
                
                String inid = dt.getValueAt(i, 0).toString(); // get inid
                String P_name = dt.getValueAt(i, 1).toString(); // get product name
                String bar_code = dt.getValueAt(i, 2).toString(); // get barcode
                String qty = dt.getValueAt(i, 3).toString(); // get product qty
                String un_price = dt.getValueAt(i, 4).toString(); // get product unit price
                String tot_price = dt.getValueAt(i, 5).toString(); // get product total Price
            
                // cart DB
             Double tot = Double.valueOf(bill_tot.getText());
             Double pid = Double.valueOf(paid_amt.getText());
             java.util.Date date = new java.util.Date();
             java.sql.Date sqldate = new java.sql.Date(date.getTime());
             java.sql.Timestamp sqltime = new java.sql.Timestamp(date.getTime());
             String l_inr = null;
             if (pid.equals(0.0)) {
                l_inr = "Invoice No";
                
            }else if (tot>pid) {
                 l_inr = "Invoice No";
                 
            }else if (tot<=pid) {
                l_inr = "Receipt No";
            }
             Statement s = db.mycon().createStatement();
             s.executeUpdate(" INSERT INTO cart (in_receipt,INID, Product_Name, Bar_code, qty, Unit_Price, Total_Price,c_date,c_time) VALUES ('"+l_inr+"','"+inid+"','"+P_name+"','"+bar_code+"','"+qty+"','"+un_price+"','"+tot_price+"','"+sqldate+"','"+sqltime+"') ");
           
            }
            
                JOptionPane.showMessageDialog(null, "Data Saved");
            
        } catch (HeadlessException | SQLException e) {
            System.out.println(e);
        }
  
        try {
            
            
            // sales DB
             
             //`saleid`, `INID`, `Cid`, `Customer_Name`, `Total_Qty`, `Total_Bill`, `Status`, `Balance`
            String inv_id = inid.getText();
            String cname  = com_cus.getSelectedItem().toString();
            String totqty = tot_qty.getText();
            String tot_bil = bill_tot.getText();
            String s_eid = s_eidd.getText();
            
            
            //String blnc = balance.getText();
            //String cid = lbl_cid.getText();
            
             // paid check
             //double c_blnc = Double.valueOf(balance.getText());
             Double tot = Double.valueOf(bill_tot.getText());
             Double pid = Double.valueOf(paid_amt.getText());
             java.util.Date date = new java.util.Date();
             java.sql.Date sqldate = new java.sql.Date(date.getTime());
             java.sql.Timestamp sqltime = new java.sql.Timestamp(date.getTime());
             String Status = null;
             String l_inr = null;
              
             if (pid.equals(0.0)) {
                 
                Status = "Unsettled";
                l_inr = "Invoice No";
                
            }else if (tot>pid) {
                 Status = "Partial";
                 l_inr = "Invoice No";
                 
            }else if (tot<=pid) {
                Status = "Paid";
                l_inr = "Receipt No";
            }
             
            
            
             
             Statement ss = db.mycon().createStatement();
             ss.executeUpdate("INSERT INTO sales(in_receipt,INID,Cid, Customer_Name,Total_Qty, Total_Bill,Paid_Amount, Status, Balance,s_date,s_time,eid) VALUES('"+l_inr+"','"+inv_id+"','"+cus_id+"','"+cname+"','"+totqty+"','"+tot_bil+"','"+pid+"','"+Status+"','"+c_blnc+"','"+sqldate+"','"+sqltime+"','"+s_eid+"')");
             
             if (c_blnc<0.0){
               Statement s = db.mycon().createStatement();
               s.executeUpdate("UPDATE customer SET debt = debt- '"+balance.getText()+"' WHERE cid ='" +lbl_cid.getText()+ "'");
            }
                
            
            
        } catch (NumberFormatException | SQLException e) {
            Logger.getLogger(sale.class.getName()).log(Level.SEVERE, null, e);
        }
  
        // save last inid number
        try {
            
           String id = inid.getText(); 
            Statement s = db.mycon().createStatement();
            s.executeUpdate("UPDATE extra SET val='"+id+"' WHERE exid = 1");
            
            
        } catch (SQLException e) {
            System.out.println(e);
        }

         // Print or view ireport bill
        
        
        try {
            
           
        HashMap para = new HashMap();
        
        para.put("inv_id", inid.getText());  // inv_id  is ireport parameter name
        
        ReportView r =new ReportView("src\\report\\print1.jasper", para);
        r.setVisible(true);  
            
            
            
        } catch (Exception e) {
        }
        sale sl = new sale();
        SwingUtilities.updateComponentTreeUI(sl);
             }
            }
            else{
                
            }
        
    }//GEN-LAST:event_b_payActionPerformed

    private void p_qtyKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_p_qtyKeyReleased
        pro_tot_cal();// product calculation
    }//GEN-LAST:event_p_qtyKeyReleased

    private void paid_amtKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_paid_amtKeyReleased
       tot();
    }//GEN-LAST:event_paid_amtKeyReleased

    private void com_cusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_com_cusActionPerformed
       // get cid 
        
        String  name =com_cus.getSelectedItem().toString();
        
        try {
            
            Statement s = db.mycon().createStatement();
            ResultSet rs = s.executeQuery("SELECT cid,customer_name FROM customer  WHERE customer_name ='"+name+"'  ");
            if (rs.next()) {
                 
               
               cus_id = (rs.getString("cid"));
               lbl_cid.setText(rs.getString("cid"));
               
                
                
            }
          
            
            
        } catch (SQLException e) {
            System.out.println(e);
        }
        
        try{
          Statement s1 = db.mycon().createStatement();
          ResultSet rs1 = s1.executeQuery("select count(*) from sales where customer_name='"+name+"'");
          
            while(rs1.next()){
            cus_qty.setText(""+rs1.getInt(1));
             
            }
   
            }catch (SQLException e){
                System.out.println(e);
            }
        
    }//GEN-LAST:event_com_cusActionPerformed

    private void br_codeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_br_codeActionPerformed
        
    }//GEN-LAST:event_br_codeActionPerformed

    private void br_codeKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_br_codeKeyReleased
        // load unit price
       
        String  name = br_code.getText();
        try {
            
            Statement s = db.mycon().createStatement();
            ResultSet rs = s.executeQuery("SELECT product_name,sell_price,qty FROM product WHERE bar_code ='"+name+"'  ");
           if (rs.next()) {
                 
                com_pro.setText(rs.getString("product_name"));
                u_price.setText(rs.getString("sell_price"));
                l_stqty.setText(rs.getString("Qty"));
                p_qty.requestFocus();
                
                
            }
          
        
        
           pro_tot_cal();
           
            
            
        } catch (SQLException e) {
            System.out.println(e);
        }
        
    }//GEN-LAST:event_br_codeKeyReleased

    private void br_codeKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_br_codeKeyPressed
        
       // String barcode = br_code.getText();
       /* String  name = br_code.toString();
        
        if(evt.getKeyCode() == KeyEvent.VK_ENTER){
        
        try {
            
            Statement s = db.mycon().createStatement();
            ResultSet rs = s.executeQuery("SELECT product_name,sell_price,qty FROM product WHERE bar_code ='"+name+"'  ");
           if (rs.next()) {
                 
                com_cus.setSelectedItem(rs.getString("product_name"));
                u_price.setText(rs.getString("sell_price"));
                l_stqty.setText(rs.getString("qty"));
             
                
                
            }
          
        
        
           pro_tot_cal();
            
            /*JOptionPane.showMessageDialog(this, "Your barcode number is: " + barcode);
            
            //java.util.Date date = new java.util.Date();
            //java.sql.Date sqldate = new java.sql.Date(date.getTime());
            //java.sql.Timestamp sqltime = new java.sql.Timestamp(date.getTime());
            
          
            
            pst =  con.prepareStatement ("SELECT * FROM product WHERE bar_code =?");
            pst.setString(1, barcode);
            rs = pst.executeQuery(); */
            
           /* if(rs.next()==true){
            
               pst = con.prepareStatement("INSERT INTO cart (bar_code,sell_price,qty) VALUES (?,?,?,?)");
               pst.setString(1,barcode); 
               //pst.setDate(2, sqldate);
               //pst.setTimestamp(3, sqltime);
               
               int q = pst.executeUpdate();
               
  
               
               if(q==1){
               
                   JOptionPane.showMessageDialog(this,"Added Successfully!");
                   br_code.setText("");
                   br_code.requestFocus();
                   loadcart(); 
               
               }else{
                   JOptionPane.showMessageDialog(this,"Error!");
               } 
            
               
            }else{
                   JOptionPane.showMessageDialog(this,"Barcode not found!");
               } */
            
       // }catch (Exception e){
        //    Logger.getLogger(sale.class.getName()).log(Level.SEVERE, null, e);
       // }
       // }
        
    }//GEN-LAST:event_br_codeKeyPressed

    private void br_codeFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_br_codeFocusGained
        br_code.requestFocus();
    }//GEN-LAST:event_br_codeFocusGained

    private void s_tblMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_s_tblMouseClicked
        int r = s_tbl.getSelectedRow();
        
        
        String id  = s_tbl.getValueAt(r, 0).toString();
        String pname  = s_tbl.getValueAt(r, 1).toString();
        String bcode  = s_tbl.getValueAt(r, 2).toString();
        String qty  = s_tbl.getValueAt(r, 3).toString();
        String uprice  = s_tbl.getValueAt(r, 4).toString();
        String tprice  = s_tbl.getValueAt(r, 5).toString();
        
        inid.setText(id);
        br_code.setText(bcode);
        com_pro.setText(pname);
        p_qty.setText(qty);
        u_price.setText(uprice);
        tot_price.setText(tprice);
        
    }//GEN-LAST:event_s_tblMouseClicked

    private void p_qtyKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_p_qtyKeyPressed
            
        if (evt.getKeyCode()==KeyEvent.VK_ENTER){
        
          String bcode = String.valueOf(br_code.getText());
          if(bcode.isEmpty()){
             JOptionPane.showMessageDialog(null,"You still not choose any product yet."); 
          }
          else{
          //add  cart to product details 
        
      int sell_qty = Integer.valueOf(p_qty.getText());
      int stk_qty = Integer.valueOf(l_stqty.getText());
      
     if (sell_qty <= stk_qty && sell_qty != 0){
     
         DefaultTableModel dt = (DefaultTableModel) s_tbl.getModel();
        
        Vector v = new Vector();
        
        
        
        v.add(inid.getText()); // invoice id
        v.add(com_pro.getText()); // product name
        v.add(br_code.getText()); // barcode
        v.add(p_qty.getText()); // p qyt
        v.add(u_price.getText()); // unit price
        v.add(tot_price.getText()); // get total price
        
        dt.addRow(v);
        
        cart_total();
       tot(); 
       minus();
       stck_qty();
       
       try{
       Statement s = db.mycon().createStatement();
       ResultSet rs = s.executeQuery("SELECT qty FROM product WHERE bar_code = '"+br_code+"'");
       
       }catch(SQLException e){
           System.out.println(e);
                   
       }
         
     }
     else{
   
        JOptionPane.showMessageDialog(null, "Stock have " +stk_qty+ " quantity only.");
     
     }}}
        
    }//GEN-LAST:event_p_qtyKeyPressed

    private void com_cusKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_com_cusKeyReleased
        
    }//GEN-LAST:event_com_cusKeyReleased

    private void s_employeeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_s_employeeActionPerformed
        // get eid 
        
        
        
        String  name =s_employee.getSelectedItem().toString();
        try {

            Statement s = db.mycon().createStatement();
            ResultSet rs = s.executeQuery("SELECT * FROM employee WHERE employee_name ='"+name+"'  ");
            if (rs.next()) {

                ss_eid = rs.getString("eid");
                s_eidd.setText(rs.getString("eid"));
                

            }

        } catch (SQLException e) {
            System.out.println(e);
        }
    }//GEN-LAST:event_s_employeeActionPerformed

    private void s_employeeKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_s_employeeKeyReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_s_employeeKeyReleased

    private void com_proFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_com_proFocusGained
        // TODO add your handling code here:
    }//GEN-LAST:event_com_proFocusGained

    private void com_proActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_com_proActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_com_proActionPerformed

    private void com_proKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_com_proKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_com_proKeyPressed

    private void com_proKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_com_proKeyReleased
         // load unit price
       
        String  name = com_pro.getText();
        try {
            
            Statement s = db.mycon().createStatement();
            ResultSet rs = s.executeQuery("SELECT bar_code,sell_price,qty FROM product WHERE product_name ='"+name+"'  ");
           if (rs.next()) {
                 
                br_code.setText(rs.getString("bar_code"));
                u_price.setText(rs.getString("sell_price"));
                l_stqty.setText(rs.getString("Qty"));
                p_qty.requestFocus();
                
                
            }
          
        
        
           pro_tot_cal();
           
            
            
        } catch (SQLException e) {
            System.out.println(e);
        }
    }//GEN-LAST:event_com_proKeyReleased


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton b_pay;
    private javax.swing.JLabel balance;
    private javax.swing.JLabel bill_tot;
    public javax.swing.JTextField br_code;
    private javax.swing.JComboBox<String> com_cus;
    public javax.swing.JTextField com_pro;
    private javax.swing.JLabel cus_qty;
    private javax.swing.JButton dcart_btn;
    private javax.swing.JLabel inid;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel l_stqty;
    private javax.swing.JLabel lbl_cid;
    private javax.swing.JTextField p_qty;
    private javax.swing.JTextField paid_amt;
    public javax.swing.JButton rmv_all_btn;
    public javax.swing.JButton rmv_btn;
    public javax.swing.JLabel s_eidd;
    public javax.swing.JComboBox<String> s_employee;
    private javax.swing.JTable s_tbl;
    private javax.swing.JLabel tot_price;
    private javax.swing.JLabel tot_qty;
    private javax.swing.JLabel u_price;
    // End of variables declaration//GEN-END:variables
}
