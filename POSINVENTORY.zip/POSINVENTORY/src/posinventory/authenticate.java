package posinventory;

import java.awt.Color;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JFrame;
import javax.swing.JOptionPane;


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author john paul
 */
public class authenticate extends javax.swing.JFrame {

    sale sl = new sale();
    Connection con = null;
    ResultSet rs = null;
    ResultSet rs1 = null;
    PreparedStatement pst = null;
    
    public authenticate() {
        //this.setLocationRelativeTo(null);
        initComponents();
        this.setLocationRelativeTo(null);
        
        
        con = db.mycon();
    }

    
   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jpass1 = new javax.swing.JTextField();
        jpass = new javax.swing.JPasswordField();
        juser1 = new javax.swing.JTextField();
        juser = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();

        jLabel2.setText("jLabel2");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        jPanel1.setBackground(new java.awt.Color(245, 240, 187));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(0, 102, 102));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jpass1.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jpass1.setText("Password");
        jpass1.setEnabled(false);
        jpass1.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jpass1FocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jpass1FocusLost(evt);
            }
        });
        jpass1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jpass1ActionPerformed(evt);
            }
        });
        jPanel2.add(jpass1, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 110, 230, 40));

        jpass.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jpass.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jpassActionPerformed(evt);
            }
        });
        jpass.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jpassKeyTyped(evt);
            }
        });
        jPanel2.add(jpass, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 110, 230, 40));

        juser1.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        juser1.setText("Username");
        juser1.setEnabled(false);
        juser1.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                juser1FocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                juser1FocusLost(evt);
            }
        });
        juser1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                juser1KeyTyped(evt);
            }
        });
        jPanel2.add(juser1, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 60, 230, 40));

        juser.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        juser.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                juserFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                juserFocusLost(evt);
            }
        });
        juser.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                juserKeyTyped(evt);
            }
        });
        jPanel2.add(juser, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 60, 230, -1));

        jButton1.setBackground(new java.awt.Color(204, 204, 255));
        jButton1.setFont(new java.awt.Font("Book Antiqua", 1, 24)); // NOI18N
        jButton1.setText("LOGIN");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 180, 184, -1));

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(204, 0, 0));
        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/posinventory/img/red-back-hi.png"))); // NOI18N
        jLabel6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel6MouseClicked(evt);
            }
        });
        jPanel2.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 10, -1, -1));

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 360, 300));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
       //login code here
       
       String un = juser.getText();
       String ps = jpass.getText();
       
        
       try{
           
            String sql = "SELECT * FROM login WHERE user_name=? AND password=?";
            pst = con.prepareCall(sql);
            
            pst.setString(1,un);
            pst.setString(2,ps);
            
            rs = pst.executeQuery();
            
            if ((rs.next())){
                sign_up sign = new sign_up();
                sign.setVisible(true);
                dispose();

            }
            else{
                JOptionPane.showMessageDialog(rootPane, "Unable to login due to failed authorization..... ");
            }
            
        }catch(Exception e){
            
        }
       
    }//GEN-LAST:event_jButton1ActionPerformed

    private void juserFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_juserFocusGained
       /* if (juser.getText().equals("Enter Username"))
        {
            juser.setText("");
            juser.setForeground(new Color(153,153,153));
        }*/
    }//GEN-LAST:event_juserFocusGained

    private void juserFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_juserFocusLost
        /*if (juser.getText().equals(""))
        {
            juser.setText("Enter Username");
            juser.setForeground(new Color(153,153,153));
        }*/
    }//GEN-LAST:event_juserFocusLost

    private void juserKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_juserKeyTyped
        if ("".equals(juser.getText()))
        {
            juser1.setVisible(true);
            juser1.setEnabled(false);
        }
        else{
            juser1.setVisible(false);
            juser1.setEnabled(false); 
         }
    }//GEN-LAST:event_juserKeyTyped

    private void juser1FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_juser1FocusGained
        // TODO add your handling code here:
    }//GEN-LAST:event_juser1FocusGained

    private void juser1FocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_juser1FocusLost
        // TODO add your handling code here:
    }//GEN-LAST:event_juser1FocusLost

    private void juser1KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_juser1KeyTyped
        // TODO add your handling code here:
    }//GEN-LAST:event_juser1KeyTyped

    private void jpass1FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jpass1FocusGained
        // TODO add your handling code here:
    }//GEN-LAST:event_jpass1FocusGained

    private void jpass1FocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jpass1FocusLost
        // TODO add your handling code here:
    }//GEN-LAST:event_jpass1FocusLost

    private void jpass1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jpass1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jpass1ActionPerformed

    private void jpassActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jpassActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jpassActionPerformed

    private void jpassKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jpassKeyTyped
        if ("".equals(jpass.getText()))
        {
            jpass1.setVisible(true);
            jpass1.setEnabled(false);
        }
        else{
            jpass1.setVisible(false);
            jpass1.setEnabled(false); 
         }
    }//GEN-LAST:event_jpassKeyTyped

    private void jLabel6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel6MouseClicked
        //login log = new login();
        //log.setVisible(true);
        dispose();
    }//GEN-LAST:event_jLabel6MouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(authenticate.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(authenticate.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(authenticate.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(authenticate.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new authenticate().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPasswordField jpass;
    private javax.swing.JTextField jpass1;
    private javax.swing.JTextField juser;
    private javax.swing.JTextField juser1;
    // End of variables declaration//GEN-END:variables
}
