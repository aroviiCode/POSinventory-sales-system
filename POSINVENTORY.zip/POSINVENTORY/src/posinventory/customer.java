/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package posinventory;

import java.awt.HeadlessException;
import java.awt.event.KeyEvent;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author john paul
 */
public class customer extends javax.swing.JPanel {

     String id = "0";
    public customer() {
        initComponents();
        tb_load();
        tb1_load();
        cust_load();
        debt_load();
        
    }
    
    public void cust_load(){
     try {
                    
          Statement s= db.mycon().createStatement();
          
          ResultSet rs = s.executeQuery("SELECT * FROM customer");
          Vector v = new Vector();
          
          while (rs.next()) {              
              v.add(rs.getString("customer_name"));
              
              DefaultComboBoxModel com = new DefaultComboBoxModel(v);
              txt_cname.setModel(com);
               
          }
           
      } catch (SQLException e) {
            System.out.println(e);
      }
    }
    public void debt_load(){
     try {
          DefaultTableModel dt = (DefaultTableModel) debt_tbl.getModel();
          dt.setRowCount(0);
          
          Statement s = db.mycon().createStatement();
          
          ResultSet rs = s.executeQuery("SELECT * FROM debt");
          
          
          while (rs.next()) {              
              Vector v = new Vector();
              
              v.add(rs.getString(1));
              v.add(rs.getString(2));
              v.add(rs.getString(3));
              v.add(rs.getString(4));
              v.add(rs.getString(5));
              
              
              dt.addRow(v);
               
          }
           
      } catch (SQLException e) {
            System.out.println(e);
      }
    }
      
 public void tb_load(){
  
  
      try {
          
          DefaultTableModel dt = (DefaultTableModel) cus_tb.getModel();
          dt.setRowCount(0);
          
          Statement s = db.mycon().createStatement();
          ResultSet rs = s.executeQuery(" SELECT * FROM customer");
          
          while (rs.next()) {              
              
              Vector v = new Vector();
              
              v.add(rs.getString(1));
              v.add(rs.getString(2));
              v.add(rs.getString(3));
              v.add(rs.getString(4));
              v.add(rs.getString(5));
              v.add(rs.getString(6));
              v.add(rs.getString(7));
              v.add(rs.getString(8));
              v.add(rs.getString(9));
              
              
              dt.addRow(v);
                          
              
              
              
          }
          
      } catch (SQLException e) {
          System.out.println(e);
      }
  
  } 
 public void tb1_load(){
  
  
      try {
          
          DefaultTableModel dt = (DefaultTableModel) debt_tbl.getModel();
          dt.setRowCount(0);
          
          Statement s = db.mycon().createStatement();
          ResultSet rs = s.executeQuery(" SELECT cid,customer_name FROM customer");
          
          while (rs.next()) {              
              
              Vector v = new Vector();
              
              v.add(rs.getString(1));
              v.add(rs.getString(2));
              
              
              dt.addRow(v);
                          
              
              
              
          }
          
      } catch (SQLException e) {
          System.out.println(e);
      }
  
  } 
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel3 = new javax.swing.JPanel();
        c_search = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        c_name = new javax.swing.JTextField();
        save_btn = new javax.swing.JButton();
        update_btn = new javax.swing.JButton();
        del_btn = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        c_add = new javax.swing.JTextField();
        c_contact = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        c_mobile = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        c_tp = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        c_gender = new javax.swing.JComboBox<>();
        c_bday = new com.toedter.calendar.JDateChooser();
        jLabel5 = new javax.swing.JLabel();
        c_search_tbl = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        cus_tb = new javax.swing.JTable();
        jLabel7 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        orderlbl = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        amntlbl = new javax.swing.JLabel();
        jPanel7 = new javax.swing.JPanel();
        jPanel8 = new javax.swing.JPanel();
        jLabel15 = new javax.swing.JLabel();
        txt_cid = new javax.swing.JTextField();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        txt_debt = new javax.swing.JTextField();
        jLabel18 = new javax.swing.JLabel();
        txt_amnt = new javax.swing.JTextField();
        save = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        debt_tbl = new javax.swing.JTable();
        txt_cname = new javax.swing.JComboBox<>();

        jPanel1.setBackground(new java.awt.Color(180, 205, 230));
        jPanel1.setForeground(new java.awt.Color(204, 204, 204));

        jPanel3.setBackground(new java.awt.Color(162, 179, 139));
        jPanel3.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        c_search.setEditable(false);
        c_search.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        c_search.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                c_searchActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(51, 51, 51));
        jLabel3.setText("ID:");

        jLabel4.setFont(new java.awt.Font("Bell MT", 2, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(51, 51, 51));
        jLabel4.setText("Customer's Information");

        jPanel2.setBackground(new java.awt.Color(162, 179, 139));
        jPanel2.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(51, 51, 51));
        jLabel1.setText("NAME:");

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(51, 51, 51));
        jLabel2.setText("Gender:");

        c_name.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N

        save_btn.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        save_btn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/posinventory/img/sign-check-icon.png"))); // NOI18N
        save_btn.setText("SAVE");
        save_btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                save_btnActionPerformed(evt);
            }
        });

        update_btn.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        update_btn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/posinventory/img/update.png"))); // NOI18N
        update_btn.setText("UPDATE");
        update_btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                update_btnActionPerformed(evt);
            }
        });

        del_btn.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        del_btn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/posinventory/img/Delete-Button.png"))); // NOI18N
        del_btn.setText("DELETE");
        del_btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                del_btnActionPerformed(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(51, 51, 51));
        jLabel6.setText("ADDRESS:");

        c_add.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N

        c_contact.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(51, 51, 51));
        jLabel8.setText("CONTACT PERSON:");

        c_mobile.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(51, 51, 51));
        jLabel9.setText("MOBILE:");

        jLabel12.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(51, 51, 51));
        jLabel12.setText("C.P NUMBER:");

        c_tp.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N

        jLabel13.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(51, 51, 51));
        jLabel13.setText("BIRTHDAY:");

        c_gender.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        c_gender.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Male", "Female", "Non-binary", "Prefer not to say" }));

        c_bday.setDateFormatString("MMMM dd, yyyy");
        c_bday.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(42, 42, 42)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(8, 8, 8)
                                .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(c_tp, javax.swing.GroupLayout.PREFERRED_SIZE, 271, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(40, 40, 40)
                                .addComponent(jLabel9)
                                .addGap(18, 18, 18)
                                .addComponent(c_mobile, javax.swing.GroupLayout.PREFERRED_SIZE, 271, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(save_btn)
                                .addGap(34, 34, 34)
                                .addComponent(update_btn)
                                .addGap(28, 28, 28)
                                .addComponent(del_btn))
                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel2Layout.createSequentialGroup()
                                    .addGap(21, 21, 21)
                                    .addComponent(jLabel13)
                                    .addGap(18, 18, 18)
                                    .addComponent(c_bday, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel2Layout.createSequentialGroup()
                                    .addGap(30, 30, 30)
                                    .addComponent(jLabel6)
                                    .addGap(18, 18, 18)
                                    .addComponent(c_add, javax.swing.GroupLayout.PREFERRED_SIZE, 271, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel8)
                        .addGap(18, 18, 18)
                        .addComponent(c_contact, javax.swing.GroupLayout.PREFERRED_SIZE, 267, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(25, 25, 25)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel2)
                            .addComponent(jLabel1))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(c_name, javax.swing.GroupLayout.PREFERRED_SIZE, 271, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(c_gender, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(c_name, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(c_gender, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(26, 26, 26)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(c_tp, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel12))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel13)
                    .addComponent(c_bday, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(21, 21, 21)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(c_add, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(c_contact, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(c_mobile, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9))
                .addGap(37, 37, 37)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(save_btn)
                    .addComponent(update_btn)
                    .addComponent(del_btn))
                .addContainerGap(106, Short.MAX_VALUE))
        );

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(51, 51, 51));
        jLabel5.setText("SEARCH:");

        c_search_tbl.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        c_search_tbl.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                c_search_tblActionPerformed(evt);
            }
        });
        c_search_tbl.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                c_search_tblKeyReleased(evt);
            }
        });

        jLabel11.setText("Customer Name");

        cus_tb.setBackground(new java.awt.Color(228, 220, 207));
        cus_tb.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        cus_tb.setForeground(new java.awt.Color(0, 102, 102));
        cus_tb.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "ID", "Customer Name", "Gender", "C.P Number", "Birthday", "Address", "Contact Person", "Mobile", "Debt"
            }
        ));
        cus_tb.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cus_tbMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(cus_tb);

        jLabel7.setFont(new java.awt.Font("Bell MT", 2, 18)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(51, 51, 51));
        jLabel7.setText("No. of Transactions");

        orderlbl.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        orderlbl.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        orderlbl.setText("X");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(orderlbl, javax.swing.GroupLayout.DEFAULT_SIZE, 151, Short.MAX_VALUE)
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(48, 48, 48)
                .addComponent(orderlbl)
                .addContainerGap(50, Short.MAX_VALUE))
        );

        jLabel10.setFont(new java.awt.Font("Bell MT", 2, 18)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(51, 51, 51));
        jLabel10.setText("Total Amount");

        amntlbl.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        amntlbl.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        amntlbl.setText("X");

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(amntlbl, javax.swing.GroupLayout.DEFAULT_SIZE, 154, Short.MAX_VALUE)
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(45, 45, 45)
                .addComponent(amntlbl)
                .addContainerGap(53, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel4))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(39, 39, 39)
                        .addComponent(jLabel3)
                        .addGap(18, 18, 18)
                        .addComponent(c_search, javax.swing.GroupLayout.PREFERRED_SIZE, 189, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jScrollPane1)
                        .addContainerGap())
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(jLabel5)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel11)
                                    .addComponent(c_search_tbl, javax.swing.GroupLayout.PREFERRED_SIZE, 224, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(82, 82, 82)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(0, 298, Short.MAX_VALUE))))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(c_search, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel3Layout.createSequentialGroup()
                            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel5)
                                .addComponent(c_search_tbl, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGap(18, 18, 18))
                        .addComponent(jLabel11, javax.swing.GroupLayout.Alignment.TRAILING)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 313, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(5, 5, 5)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Customer's Information", jPanel3);

        jPanel8.setBackground(new java.awt.Color(180, 205, 230));

        jLabel15.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(51, 51, 51));
        jLabel15.setText("Customer ID:");

        txt_cid.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        txt_cid.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_cidActionPerformed(evt);
            }
        });
        txt_cid.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txt_cidKeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txt_cidKeyReleased(evt);
            }
        });

        jLabel16.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(51, 51, 51));
        jLabel16.setText("Customer Name:");

        jLabel17.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(51, 51, 51));
        jLabel17.setText("Total Debt:");

        txt_debt.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        txt_debt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_debtActionPerformed(evt);
            }
        });
        txt_debt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txt_debtKeyReleased(evt);
            }
        });

        jLabel18.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel18.setForeground(new java.awt.Color(51, 51, 51));
        jLabel18.setText("Amount Payed:");

        txt_amnt.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        txt_amnt.setText("0");
        txt_amnt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_amntActionPerformed(evt);
            }
        });
        txt_amnt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txt_amntKeyReleased(evt);
            }
        });

        save.setBackground(new java.awt.Color(204, 255, 153));
        save.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        save.setText("PAY");
        save.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveActionPerformed(evt);
            }
        });

        debt_tbl.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        debt_tbl.setForeground(new java.awt.Color(0, 102, 102));
        debt_tbl.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Debt ID", "Customer ID", "Customer Name", "Amount Payed", "Date"
            }
        ));
        debt_tbl.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                debt_tblMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(debt_tbl);

        txt_cname.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        txt_cname.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select" }));
        txt_cname.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_cnameActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane3)
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel8Layout.createSequentialGroup()
                                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel15)
                                    .addComponent(txt_cid, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel16)
                                    .addComponent(txt_cname, javax.swing.GroupLayout.PREFERRED_SIZE, 241, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txt_debt, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel17)))
                            .addGroup(jPanel8Layout.createSequentialGroup()
                                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel18)
                                    .addComponent(txt_amnt, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addComponent(save, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 525, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel8Layout.createSequentialGroup()
                            .addComponent(jLabel15)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(txt_cid, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel8Layout.createSequentialGroup()
                            .addComponent(jLabel16)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(txt_cname, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel8Layout.createSequentialGroup()
                        .addComponent(jLabel17)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txt_debt, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addComponent(jLabel18)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt_amnt, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(save))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 202, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(206, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel8, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jTabbedPane1.addTab("Debt Paying", jPanel7);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane1)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 611, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
    }// </editor-fold>//GEN-END:initComponents

    private void save_btnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_save_btnActionPerformed
        
        String name = c_name.getText();
        String gender = c_gender.getSelectedItem().toString();
        String add = c_add.getText();
        String tp = c_tp.getText();
        
        //Double tp1 = Double.valueOf(c_tp.getText());
        Date bday = c_bday.getDate();
        String conp = c_contact.getText();
        String mob = c_mobile.getText();
        
        //int tp1 = Integer.valueOf(c_tp.getText());
        
        if (name.equals("")){
           JOptionPane.showMessageDialog(null, "Please input a name."); 
        }
        else if (add.equals("")){
           JOptionPane.showMessageDialog(null, "Please input an address.");  
        }
        else if (tp.length() != 11){
           JOptionPane.showMessageDialog(null, "Please input 11 digit contact number.");  
            }
        
        
        else{
        
        try {
        
            Statement s = db.mycon().createStatement();
            ResultSet rs = s.executeQuery(("SELECT * FROM customer WHERE customer_name = '"+name+"' "));
            
            
            if (rs.next()){
                JOptionPane.showMessageDialog(null, "Data already exist.");
            }
            
            else{
                
            if (tp.equals("")){
             tp = "N/A";
            }
            if (conp.equals("")){
                conp = "N/A";
            }
            if (mob.equals("")){
                mob = "N/A";
            }
                // `pid`, `Product_Name`, `Bar_code`, `Price`, `Qty`, `Sid`
               s.executeUpdate(" INSERT INTO customer (customer_name,gender,tp_number,birthday,address,contact_person,mobile) "
                    + "VALUES ('"+name+"','"+gender+"','"+tp+"','"+bday+"','"+add+"','"+conp+"','"+mob+"')"); 
            JOptionPane.showMessageDialog(null, "Data saved");
            }
            

        } catch (NumberFormatException | SQLException e) {
            System.out.println(e);
        }
        tb_load();
        }

    }//GEN-LAST:event_save_btnActionPerformed

    private void update_btnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_update_btnActionPerformed
       
        
        int reply = JOptionPane.showConfirmDialog(null, "Are you sure you want to update this customer information?", "Warning", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
        if (reply == JOptionPane.YES_OPTION) {
            
        String id = c_search.getText();
        String name = c_name.getText();
        String gender = c_gender.getSelectedItem().toString();
        String add = c_add.getText();
        String tp = c_tp.getText();
        Date bday = c_bday.getDate();
        String conp = c_contact.getText();
        String mob = c_mobile.getText();
        
        
        try {
            
            Statement s = db.mycon().createStatement();
            s.executeUpdate("UPDATE customer SET customer_name ='"+name+"',gender ='"+gender+"' ,Tp_Number ='"+tp+"',birthday ='"+bday+"',address ='"+add+"',contact_person ='"+conp+"',mobile ='"+mob+"' WHERE cid = '"+id+"' ");
             JOptionPane.showMessageDialog(null, "Data Updated");
            
            
        } catch (Exception e) {
            Logger.getLogger(customer.class.getName()).log(Level.SEVERE, null, e);
        }
        
         tb_load();
        }
         else{
        }
    }//GEN-LAST:event_update_btnActionPerformed

    private void del_btnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_del_btnActionPerformed
       
        int reply = JOptionPane.showConfirmDialog(null, "Are you sure you want to delete this customer's data?", "Warning", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
        if (reply == JOptionPane.YES_OPTION) {
        String id = c_search.getText();

        try {
            Statement s = db.mycon().createStatement();
            s.executeUpdate("DELETE FROM customer WHERE cid = '"+id+"' ");
            JOptionPane.showMessageDialog(null, "Data Deleted");

        } catch (HeadlessException | SQLException e) {
            System.out.println(e);
        }

        tb_load();
        } 
        else {
        
        }
      
    }//GEN-LAST:event_del_btnActionPerformed

    private void cus_tbMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cus_tbMouseClicked
        // mouse clk & get data to textfeld
      DefaultTableModel dt = (DefaultTableModel) cus_tb.getModel();  
      int r = cus_tb.getSelectedRow();
     
      String id = cus_tb.getValueAt(r, 0).toString();
      String name = cus_tb.getValueAt(r, 1).toString();
      String gender = cus_tb.getValueAt(r, 2).toString();
      String tp = cus_tb.getValueAt(r, 3).toString();
      String bday = cus_tb.getValueAt(r, 4).toString();
      String ad = cus_tb.getValueAt(r, 5).toString();
      String cp = cus_tb.getValueAt(r, 6).toString();
      String cpm = cus_tb.getValueAt(r, 7).toString();
      
      c_search.setText(id);
      c_name.setText(name);
      c_gender.setSelectedItem(gender);
      c_tp.setText(tp);
      ((JTextField)c_bday.getDateEditor().getUiComponent()).setText(bday);
      c_add.setText(ad);
      c_contact.setText(cp);
      c_mobile.setText(cpm);
      
      try{
          Statement s = db.mycon().createStatement();
          ResultSet rs = s.executeQuery("select count(*) from sales where customer_name='"+dt.getValueAt(r, 1).toString()+"'");
          Statement s1 = db.mycon().createStatement();
          ResultSet rs1 = s1.executeQuery("select sum(total_bill) from sales where customer_name='"+dt.getValueAt(r, 1).toString()+"'");
          Statement s2 = db.mycon().createStatement();
          ResultSet rs2 = s2.executeQuery("select sum(balance) from sales where balance < 0 AND customer_name='"+dt.getValueAt(r, 1).toString()+"' ");
        while(rs.next()){
            orderlbl.setText(""+rs.getInt(1));
            }
        while (rs1.next()){
            amntlbl.setText("Php "+rs1.getDouble(1));
            }
        /*while(rs2.next()){
            debtlbl.setText("Php "+rs2.getDouble(1));
            }*/
            }catch (SQLException e){
                System.out.println(e);
            }
      
      
    }//GEN-LAST:event_cus_tbMouseClicked

    private void c_search_tblKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_c_search_tblKeyReleased
       
        String name = c_search_tbl.getText();
        try {
            
            DefaultTableModel dt = (DefaultTableModel) cus_tb .getModel();
            dt.setRowCount(0);
            Statement s = db.mycon().createStatement();
            
            ResultSet rs = s.executeQuery("SELECT * FROM customer WHERE customer_name LIKE '%"+name+"%' ");
            
            while (rs.next()) {                
                Vector v = new Vector();
                
                v.add(rs.getString(1));
                v.add(rs.getString(2));
                v.add(rs.getString(3));
                 v.add(rs.getString(4));
                v.add(rs.getString(5));
                v.add(rs.getString(6));
                v.add(rs.getString(7));
                v.add(rs.getString(8));
                v.add(rs.getString(9));
                
                dt.addRow(v);
                
                
            }
            
            
            
            
            
        } catch (Exception e) {
            tb_load();
            
        }
 
    }//GEN-LAST:event_c_search_tblKeyReleased

    private void c_search_tblActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_c_search_tblActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_c_search_tblActionPerformed

    private void c_searchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_c_searchActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_c_searchActionPerformed

    private void txt_cidActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_cidActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_cidActionPerformed

    private void txt_cidKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_cidKeyReleased
        // load unit price

        String  ccid =txt_cid.getText();
        try {

            Statement s = db.mycon().createStatement();
            ResultSet rs = s.executeQuery("SELECT * FROM customer WHERE cid ='"+ccid+"'  ");
            if (rs.next()) {

                id = rs.getString("cid");
                txt_cname.setSelectedItem(rs.getString("customer_name"));
                txt_debt.setText(rs.getString("Debt"));

            }

        } catch (SQLException e) {
            System.out.println(e);
        }
    }//GEN-LAST:event_txt_cidKeyReleased

    private void txt_debtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_debtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_debtActionPerformed

    private void txt_debtKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_debtKeyReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_debtKeyReleased

    private void txt_amntActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_amntActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_amntActionPerformed

    private void txt_amntKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_amntKeyReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_amntKeyReleased

    private void saveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveActionPerformed
        // save stock

        String cust_id = txt_cid.getText();
        String cname = txt_cname.getSelectedItem().toString();
        java.util.Date date = new java.util.Date();
        //Date xp = xpdate.getDate();
        java.sql.Date sqldate = new java.sql.Date(date.getTime());
        String amnt = txt_amnt.getText();

        try {

            Statement s = db.mycon().createStatement();
            // `pid`, `Product_Name`, `Bar_code`, `Price`, `Qty`, `Sid`
            s.executeUpdate("INSERT INTO debt (cid,customer_name,amount_payed,date) VALUES ('"+cust_id+"','"+cname+"','"+amnt+"','"+sqldate+"')");
            JOptionPane.showMessageDialog(null, "Data Saved");

        } catch (SQLException e) {
            System.out.println(e);
        }

        // update Stock

        //int newqty =Integer.valueOf( txt_amnt.getText());
        //int oldqty = Integer.valueOf(txt_debt.getText());

       // int up_qty = newqty + oldqty ;

        try {

            Statement s = db.mycon().createStatement();
            s.executeUpdate("UPDATE customer SET debt = debt- '"+txt_amnt.getText()+"' WHERE cid ='" +txt_cid.getText()+ "'");

        } catch (Exception e) {
            System.out.println(e);
        }

        debt_load();
    }//GEN-LAST:event_saveActionPerformed

    private void txt_cnameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_cnameActionPerformed
        // load unit price

        String  name =txt_cname.getSelectedItem().toString();
        try {

            Statement s = db.mycon().createStatement();
            ResultSet rs = s.executeQuery("SELECT * FROM customer WHERE customer_name ='"+name+"'  ");
            if (rs.next()) {

                id = rs.getString("cid");
                txt_cid.setText(rs.getString("cid"));
                txt_debt.setText(rs.getString("debt"));

            }

        } catch (SQLException e) {
            System.out.println(e);
        }
    }//GEN-LAST:event_txt_cnameActionPerformed

    private void debt_tblMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_debt_tblMouseClicked
      
      DefaultTableModel dt = (DefaultTableModel) debt_tbl.getModel();  
      int r = debt_tbl.getSelectedRow();
      
      //String id = cust1_tbl.getValueAt(r, 0).toString();
      //String name = cust1_tbl.getValueAt(r, 1).toString();
      
      try{
          
          Statement s2 = db.mycon().createStatement();
          ResultSet rs2 = s2.executeQuery("select sum(balance) from sales where balance < 0 AND customer_name='"+dt.getValueAt(r, 1).toString()+"' ");
     
        while(rs2.next()){
            //debtlbl1.setText("Php "+rs2.getDouble(1));
            }
            }catch (SQLException e){
                System.out.println(e);
            }
      
    }//GEN-LAST:event_debt_tblMouseClicked

    private void txt_cidKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_cidKeyPressed
        // load unit price
         if (evt.getKeyCode()==KeyEvent.VK_ENTER){
        String  ccid =txt_cid.getText();
        try {

            Statement s = db.mycon().createStatement();
            ResultSet rs = s.executeQuery("SELECT * FROM customer WHERE cid ='"+ccid+"'  ");
            if (rs.next()) {

                //id = rs.getString("pid");
                txt_cname.setSelectedItem(rs.getString("customer_name"));
                txt_debt.setText(rs.getString("Debt"));

            }

        } catch (SQLException e) {
            System.out.println(e);
        }}
    }//GEN-LAST:event_txt_cidKeyPressed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel amntlbl;
    private javax.swing.JTextField c_add;
    private com.toedter.calendar.JDateChooser c_bday;
    private javax.swing.JTextField c_contact;
    private javax.swing.JComboBox<String> c_gender;
    private javax.swing.JTextField c_mobile;
    public javax.swing.JTextField c_name;
    private javax.swing.JTextField c_search;
    private javax.swing.JTextField c_search_tbl;
    private javax.swing.JTextField c_tp;
    private javax.swing.JTable cus_tb;
    private javax.swing.JTable debt_tbl;
    private javax.swing.JButton del_btn;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JLabel orderlbl;
    private javax.swing.JButton save;
    private javax.swing.JButton save_btn;
    private javax.swing.JTextField txt_amnt;
    private javax.swing.JTextField txt_cid;
    private javax.swing.JComboBox<String> txt_cname;
    private javax.swing.JTextField txt_debt;
    private javax.swing.JButton update_btn;
    // End of variables declaration//GEN-END:variables
}
