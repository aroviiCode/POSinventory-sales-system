/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package posinventory;

import static groovy.ui.text.FindReplaceUtility.dispose;
import java.awt.Color;
import java.awt.Font;
import java.awt.HeadlessException;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import static java.util.Collections.list;
import java.util.Date;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import net.proteanit.sql.DbUtils;

/**
 *
 * @author john paul
 */
public final class product extends javax.swing.JPanel {

    
    String id = "0";
    
    public product() {
        initComponents();
        tb_load();
        stock_load();
        supplier_load();
        data_load();
        cat_load();
        category_load();
        
        //listed();
    }
    public void category_load(){
         // load category
  
      try {
          
          Statement s= db.mycon().createStatement();
          
          ResultSet rs = s.executeQuery("SELECT * FROM category");
          Vector v = new Vector();
          
          while (rs.next()) {              
              v.add(rs.getString("prod_category"));
              
              DefaultComboBoxModel com = new DefaultComboBoxModel(v);
              p_cat.setModel(com);
               
          }
           
      } catch (SQLException e) {
            System.out.println(e);
      }  
    }
    public void data_load(){
         // load Product
  
      /*try {
          
          Statement s= db.mycon().createStatement();
          
          ResultSet rs = s.executeQuery("SELECT * FROM product");
          Vector v = new Vector();
          
          while (rs.next()) {              
              v.add(rs.getString("Product_Name"));
              
              DefaultComboBoxModel com = new DefaultComboBoxModel(v);
              txt_pname.setModel(com);
               
          }
           
      } catch (SQLException e) {
            System.out.println(e);
      } */ 
    }
   public void stock_load(){
  
  
      try {
          
          DefaultTableModel dt = (DefaultTableModel) stk_tbl.getModel();
          dt.setRowCount(0);
          
          Statement s = db.mycon().createStatement();
          ResultSet rs = s.executeQuery(" SELECT * FROM stock");
          
          while (rs.next()) {              
              
              Vector v = new Vector();
              
              v.add(rs.getString(1));
              v.add(rs.getString(2));
              v.add(rs.getString(3));
              v.add(rs.getString(4));
              v.add(rs.getString(5));
              v.add(rs.getString(6));
              v.add(rs.getString(7));
              
              dt.addRow(v);
                          
              
              
              
          }
          
      } catch (SQLException e) {
          System.out.println(e);
      }
  
  }   
   public void tb_load(){
          
       /* try {
          
          DefaultTableModel dt = (DefaultTableModel) pro_list.getModel();
          dt.setRowCount(0);
          
          
          
          Statement s = db.mycon().createStatement();
          ResultSet rs = s.executeQuery(" SELECT * FROM product WHERE qty > 0 AND < 10 ");
          
          if (rs.next()) {                      
            
            
            Vector v = new Vector();
              
              v.add(rs.getString(1));
              v.add(rs.getString(2));
              v.add(rs.getString(3));
              v.add(rs.getString(4));
              v.add(rs.getString(5));
              v.add(rs.getString(6));
              v.add(rs.getString(7));
              v.add(rs.getString(8));
              v.add(rs.getString(9));
              
            dt.setRow(v);
            dt.setBackground (new Color(255,255,153)); 
                          
             
              
              
          }
          
      } catch (SQLException e) {
          System.out.println(e);
      }*/
  
      try {
          
          DefaultTableModel dt = (DefaultTableModel) pro_list.getModel();
          dt.setRowCount(0);
          
          
          
          Statement s = db.mycon().createStatement();
          ResultSet rs = s.executeQuery(" SELECT * FROM product");
          
          while (rs.next()) {              
              
              Vector v = new Vector();
              
              v.add(rs.getString(1));
              v.add(rs.getString(2));
              v.add(rs.getString(3));
              v.add(rs.getString(4));
              v.add(rs.getString(5));
              v.add(rs.getString(6));
              v.add(rs.getString(7));
              v.add(rs.getString(8));
              v.add(rs.getString(9));
              
              dt.addRow(v);
                          
             
              
              
          }
          
      } catch (SQLException e) {
          System.out.println(e);
      }
  
  }  
   
   public void cat_load(){
  
  
      try {
          
          DefaultTableModel dt = (DefaultTableModel) cat_tbl.getModel();
          dt.setRowCount(0);
          
          Statement s = db.mycon().createStatement();
          ResultSet rs = s.executeQuery(" SELECT * FROM category");
          
          while (rs.next()) {              
              
              Vector v = new Vector();
              
              v.add(rs.getString(1));
              v.add(rs.getString(2));
              
              dt.addRow(v);
                          
              
              
              
          }
          
      } catch (SQLException e) {
          System.out.println(e);
      }
  
  }  
    public void supplier_load(){
    //all supplier load to com_sup combo box
     try {
          
          Statement s = db.mycon().createStatement();
          ResultSet rs = s.executeQuery("SELECT * FROM supplier");
          
          Vector v = new Vector();
          
          
          while(rs.next()){
          
              v.add(rs.getString("supplier_Name"));
              DefaultComboBoxModel cm = new DefaultComboBoxModel(v);
          
          com_sup.setModel(cm);
          }
         
         
          
      } catch (SQLException e) {
          System.out.println(e);
      }
    
    }
    
    
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        show4Permanent1 = new datechooser.demo.steps.Show4Permanent();
        jCalendarPanel1 = new de.wannawork.jcalendar.JCalendarPanel();
        jMonthPanel1 = new de.wannawork.jcalendar.JMonthPanel();
        jDateChooser1 = new com.toedter.calendar.JDateChooser();
        jPanel1 = new javax.swing.JPanel();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel3 = new javax.swing.JPanel();
        p_search = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        p_name = new javax.swing.JTextField();
        p_bcode = new javax.swing.JTextField();
        save_btn = new javax.swing.JButton();
        update_btn = new javax.swing.JButton();
        delete_btn = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        p_sprice = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        p_cprice = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        p_qty = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        p_sid = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        com_sup = new javax.swing.JComboBox<>();
        p_cat = new javax.swing.JComboBox<>();
        jLabel17 = new javax.swing.JLabel();
        p_search_tbl = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        lowstck = new javax.swing.JButton();
        jPanel7 = new javax.swing.JPanel();
        jLabel18 = new javax.swing.JLabel();
        lbl_tot_selled = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        pro_list = new javax.swing.JTable();
        jPanel4 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        jLabel13 = new javax.swing.JLabel();
        txt_br = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        txt_qty = new javax.swing.JTextField();
        jLabel16 = new javax.swing.JLabel();
        txt_newqty = new javax.swing.JTextField();
        save = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        stk_tbl = new javax.swing.JTable();
        jLabel10 = new javax.swing.JLabel();
        txt_pname = new javax.swing.JTextField();
        xpdate = new com.toedter.calendar.JDateChooser();
        jPanel6 = new javax.swing.JPanel();
        jPanel8 = new javax.swing.JPanel();
        jLabel21 = new javax.swing.JLabel();
        txt_cat = new javax.swing.JTextField();
        add = new javax.swing.JButton();
        add1 = new javax.swing.JButton();
        delete = new javax.swing.JButton();
        jScrollPane5 = new javax.swing.JScrollPane();
        cat_tbl = new javax.swing.JTable();
        catid = new javax.swing.JLabel();

        setBackground(new java.awt.Color(162, 179, 139));

        jPanel1.setBackground(new java.awt.Color(162, 179, 139));

        jTabbedPane1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jTabbedPane1KeyPressed(evt);
            }
        });

        jPanel3.setBackground(new java.awt.Color(180, 205, 230));
        jPanel3.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        p_search.setEditable(false);
        p_search.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        p_search.setText("0");

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(51, 51, 51));
        jLabel3.setText("ID:");

        jLabel4.setFont(new java.awt.Font("Bell MT", 2, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(51, 51, 51));
        jLabel4.setText("Product Information");

        jPanel2.setBackground(new java.awt.Color(162, 179, 139));
        jPanel2.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel2.setForeground(new java.awt.Color(51, 51, 51));

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(51, 51, 51));
        jLabel1.setText("PRODUCT NAME:");

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(51, 51, 51));
        jLabel2.setText("BAR CODE:");

        p_name.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        p_name.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                p_nameFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                p_nameFocusLost(evt);
            }
        });
        p_name.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                p_nameActionPerformed(evt);
            }
        });

        p_bcode.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        p_bcode.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                p_bcodeActionPerformed(evt);
            }
        });

        save_btn.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        save_btn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/posinventory/img/sign-check-icon.png"))); // NOI18N
        save_btn.setText("SAVE");
        save_btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                save_btnActionPerformed(evt);
            }
        });

        update_btn.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        update_btn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/posinventory/img/update.png"))); // NOI18N
        update_btn.setText("UPDATE");
        update_btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                update_btnActionPerformed(evt);
            }
        });

        delete_btn.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        delete_btn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/posinventory/img/Delete-Button.png"))); // NOI18N
        delete_btn.setText("DELETE");
        delete_btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                delete_btnActionPerformed(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(51, 51, 51));
        jLabel5.setText("SELL PRICE:");

        p_sprice.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        p_sprice.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                p_spriceActionPerformed(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(51, 51, 51));
        jLabel6.setText("COST PRICE:");

        p_cprice.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        p_cprice.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                p_cpriceActionPerformed(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(51, 51, 51));
        jLabel7.setText("QTY:");

        p_qty.setEditable(false);
        p_qty.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        p_qty.setText("0");
        p_qty.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                p_qtyActionPerformed(evt);
            }
        });

        jLabel11.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(51, 51, 51));
        jLabel11.setText("SUPPLIER ID:");

        p_sid.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        p_sid.setText("0");
        p_sid.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                p_sidActionPerformed(evt);
            }
        });

        jLabel12.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(51, 51, 51));
        jLabel12.setText("SUPPLIER NAME:");

        com_sup.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        com_sup.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select" }));
        com_sup.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                com_supActionPerformed(evt);
            }
        });

        p_cat.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        p_cat.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select" }));
        p_cat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                p_catActionPerformed(evt);
            }
        });

        jLabel17.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(51, 51, 51));
        jLabel17.setText("CATEGORY:");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.TRAILING))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(p_bcode, javax.swing.GroupLayout.DEFAULT_SIZE, 263, Short.MAX_VALUE)
                            .addComponent(p_name)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel12)
                                .addGap(7, 7, 7))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel11)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)))
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(p_sid)
                            .addComponent(com_sup, 0, 283, Short.MAX_VALUE))))
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(101, 101, 101)
                        .addComponent(save_btn))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(284, 284, 284)
                        .addComponent(update_btn)
                        .addGap(63, 63, 63)
                        .addComponent(delete_btn))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel17)
                                .addGap(18, 18, 18)
                                .addComponent(p_cat, javax.swing.GroupLayout.PREFERRED_SIZE, 271, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel7)
                                .addGap(18, 18, 18)
                                .addComponent(p_qty, javax.swing.GroupLayout.PREFERRED_SIZE, 271, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel6)
                            .addComponent(jLabel5))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(p_sprice)
                            .addComponent(p_cprice, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(28, 28, 28))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(p_name, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel1))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(p_bcode, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel2)))
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel2Layout.createSequentialGroup()
                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel17)
                                .addComponent(p_cat, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(p_qty, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel7)))
                        .addGroup(jPanel2Layout.createSequentialGroup()
                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(p_cprice, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel6))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel5)
                                .addComponent(p_sprice, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(p_sid, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel11))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel12)
                    .addComponent(com_sup, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(save_btn)
                    .addComponent(update_btn)
                    .addComponent(delete_btn))
                .addContainerGap(19, Short.MAX_VALUE))
        );

        p_search_tbl.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        p_search_tbl.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                p_search_tblActionPerformed(evt);
            }
        });
        p_search_tbl.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                p_search_tblKeyReleased(evt);
            }
        });

        jLabel9.setBackground(new java.awt.Color(204, 204, 204));
        jLabel9.setText("Only search for product name.");

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel8.setText("SEARCH:");

        lowstck.setBackground(new java.awt.Color(255, 153, 255));
        lowstck.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lowstck.setText("LOW STOCK");
        lowstck.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                lowstckActionPerformed(evt);
            }
        });

        jLabel18.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel18.setText("TOTAL SOLD QUANTITY:");

        lbl_tot_selled.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        lbl_tot_selled.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lbl_tot_selled.setText("X");

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addComponent(jLabel18)
                .addGap(0, 76, Short.MAX_VALUE))
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lbl_tot_selled, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addComponent(jLabel18)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lbl_tot_selled, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 13, Short.MAX_VALUE))
        );

        pro_list.setBackground(new java.awt.Color(228, 220, 207));
        pro_list.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        pro_list.setForeground(new java.awt.Color(0, 102, 102));
        pro_list.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "ID", "Product Name", "Product Category", "Bar Code", "Cost Price", "Sell Price", "Qty", "SID", "Supplier Name"
            }
        ));
        pro_list.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                pro_listMouseClicked(evt);
            }
        });
        pro_list.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                pro_listKeyPressed(evt);
            }
        });
        jScrollPane1.setViewportView(pro_list);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(jLabel4)
                                .addGap(244, 244, 244))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel3Layout.createSequentialGroup()
                                .addComponent(jLabel3)
                                .addGap(18, 18, 18)
                                .addComponent(p_search, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(74, 74, 74)
                                .addComponent(jLabel9))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(jLabel8)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(p_search_tbl, javax.swing.GroupLayout.PREFERRED_SIZE, 224, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(44, 44, 44)
                                .addComponent(lowstck)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(24, 24, 24)))
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel3Layout.createSequentialGroup()
                            .addComponent(jLabel4)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(p_search, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel3)))
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel8)
                                .addComponent(p_search_tbl, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(lowstck))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 317, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Product Information", jPanel3);

        jPanel5.setBackground(new java.awt.Color(180, 205, 230));

        jLabel13.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(51, 51, 51));
        jLabel13.setText("Barcode ID:");

        txt_br.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        txt_br.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_brActionPerformed(evt);
            }
        });
        txt_br.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txt_brKeyReleased(evt);
            }
        });

        jLabel14.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(51, 51, 51));
        jLabel14.setText("Product Name:");

        jLabel15.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(51, 51, 51));
        jLabel15.setText("Stock QTY:");

        txt_qty.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        txt_qty.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_qtyActionPerformed(evt);
            }
        });
        txt_qty.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txt_qtyKeyReleased(evt);
            }
        });

        jLabel16.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(51, 51, 51));
        jLabel16.setText("New Add/Less QTY:");

        txt_newqty.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        txt_newqty.setText("0");
        txt_newqty.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_newqtyActionPerformed(evt);
            }
        });
        txt_newqty.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txt_newqtyKeyReleased(evt);
            }
        });

        save.setBackground(new java.awt.Color(204, 255, 153));
        save.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        save.setText("SAVE");
        save.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveActionPerformed(evt);
            }
        });

        stk_tbl.setBackground(new java.awt.Color(228, 220, 207));
        stk_tbl.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        stk_tbl.setForeground(new java.awt.Color(0, 102, 102));
        stk_tbl.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "Stock ID", "Barcode", "Product Name", "Exp Date", "Stock Date", "Stock Time", "Quantity"
            }
        ));
        jScrollPane3.setViewportView(stk_tbl);

        jLabel10.setBackground(new java.awt.Color(204, 204, 204));
        jLabel10.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(51, 51, 51));
        jLabel10.setText("Exp. Date:");

        txt_pname.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        txt_pname.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txt_pnameKeyReleased(evt);
            }
        });

        xpdate.setDateFormatString("MMMM dd, yyyy");

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(jLabel16)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txt_newqty, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(save, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel13)
                            .addComponent(txt_br, javax.swing.GroupLayout.PREFERRED_SIZE, 195, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(28, 28, 28)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel14)
                            .addComponent(txt_pname, javax.swing.GroupLayout.PREFERRED_SIZE, 385, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(42, 42, 42)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txt_qty, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel15))
                        .addGap(34, 34, 34)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel10)
                            .addComponent(xpdate, javax.swing.GroupLayout.PREFERRED_SIZE, 221, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap())
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(jLabel13)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txt_br, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txt_pname, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                                .addComponent(jLabel15)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                                .addComponent(jLabel10)
                                .addGap(9, 9, 9)))
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txt_qty, javax.swing.GroupLayout.DEFAULT_SIZE, 31, Short.MAX_VALUE)
                            .addComponent(xpdate, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addComponent(jLabel14, javax.swing.GroupLayout.Alignment.LEADING))
                .addGap(18, 18, 18)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(txt_newqty, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel16))
                    .addComponent(save, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 401, Short.MAX_VALUE)
                .addGap(32, 32, 32))
        );

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel5, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jTabbedPane1.addTab("Product Stocking", jPanel4);

        jPanel6.setBackground(new java.awt.Color(180, 205, 230));

        jPanel8.setBackground(new java.awt.Color(162, 179, 139));
        jPanel8.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel21.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel21.setForeground(new java.awt.Color(51, 51, 51));
        jLabel21.setText("Category Name");

        txt_cat.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        txt_cat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_catActionPerformed(evt);
            }
        });
        txt_cat.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txt_catKeyReleased(evt);
            }
        });

        add.setBackground(new java.awt.Color(204, 255, 153));
        add.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        add.setText("ADD");
        add.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addActionPerformed(evt);
            }
        });

        add1.setBackground(new java.awt.Color(204, 255, 153));
        add1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        add1.setText("UPDATE");
        add1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                add1ActionPerformed(evt);
            }
        });

        delete.setBackground(new java.awt.Color(204, 255, 153));
        delete.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        delete.setText("DELETE");
        delete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteActionPerformed(evt);
            }
        });

        cat_tbl.setBackground(new java.awt.Color(228, 220, 207));
        cat_tbl.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        cat_tbl.setForeground(new java.awt.Color(0, 102, 102));
        cat_tbl.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null},
                {null, null},
                {null, null},
                {null, null}
            },
            new String [] {
                "Category ID", "Product Category"
            }
        ));
        cat_tbl.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cat_tblMouseClicked(evt);
            }
        });
        jScrollPane5.setViewportView(cat_tbl);

        catid.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        catid.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addGap(22, 22, 22)
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel8Layout.createSequentialGroup()
                                .addComponent(catid, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel8Layout.createSequentialGroup()
                                        .addGap(29, 29, 29)
                                        .addComponent(txt_cat, javax.swing.GroupLayout.PREFERRED_SIZE, 361, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel8Layout.createSequentialGroup()
                                        .addGap(160, 160, 160)
                                        .addComponent(jLabel21))))
                            .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 509, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addGap(110, 110, 110)
                        .addComponent(add, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(add1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(delete)))
                .addContainerGap(26, Short.MAX_VALUE))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addGap(7, 7, 7)
                        .addComponent(jLabel21)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txt_cat, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(catid, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(delete)
                    .addComponent(add1)
                    .addComponent(add))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane5, javax.swing.GroupLayout.DEFAULT_SIZE, 421, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                .addContainerGap(280, Short.MAX_VALUE)
                .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(287, 287, 287))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        jTabbedPane1.addTab("Product Category", jPanel6);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 1133, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 10, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 607, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void cat_tblMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cat_tblMouseClicked
        int r = cat_tbl.getSelectedRow();

        String cid = cat_tbl.getValueAt(r, 0).toString();
        String cat  = cat_tbl.getValueAt(r, 1).toString();

        txt_cat.setText(cat);
        catid.setText(cid);
    }//GEN-LAST:event_cat_tblMouseClicked

    private void deleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteActionPerformed
        // delete btn code

        String cat = txt_cat.getText();

        try {
            Statement s = db.mycon().createStatement();
            s.executeUpdate("DELETE FROM category WHERE prod_category = '"+cat+"' ");
            JOptionPane.showMessageDialog(null, "Data Deleted");

        } catch (HeadlessException | SQLException e) {
            System.out.println(e);
        }

        cat_load();
    }//GEN-LAST:event_deleteActionPerformed

    private void add1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_add1ActionPerformed
        // update btn code

        String cid = catid.getText();
        String cat =txt_cat.getText();

        try {

            Statement s = db.mycon().createStatement();

            s.executeUpdate("UPDATE category SET prod_category='"+cat+"' WHERE catid ='"+cid+"' ");

            JOptionPane.showMessageDialog(null, "Data Updated");

        } catch (Exception e) {
        }

        cat_load();
    }//GEN-LAST:event_add1ActionPerformed

    private void addActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addActionPerformed
        // save product

        String catname = txt_cat.getText();

        try {

            Statement s = db.mycon().createStatement();
            // `pid`, `Product_Name`, `Bar_code`, `Price`, `Qty`, `Sid`
            s.executeUpdate("INSERT INTO category (prod_category) VALUES ('"+catname+"')");
            JOptionPane.showMessageDialog(null, "Data Saved");

        } catch (SQLException e) {
            System.out.println(e);
        }

        cat_load();
    }//GEN-LAST:event_addActionPerformed

    private void txt_catKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_catKeyReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_catKeyReleased

    private void txt_catActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_catActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_catActionPerformed

    private void saveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveActionPerformed
        // save stock

        String bcode = txt_br.getText();
        String pname = txt_pname.getText();
        java.util.Date date = new java.util.Date();
        Date xp = xpdate.getDate();
        java.sql.Date sqldate = new java.sql.Date(date.getTime());
        java.sql.Timestamp sqltime = new java.sql.Timestamp(date.getTime());
        String qty = txt_newqty.getText();

        try {

            Statement s = db.mycon().createStatement();
            // `pid`, `Product_Name`, `Bar_code`, `Price`, `Qty`, `Sid`
            s.executeUpdate("INSERT INTO stock (bar_code,product_name,exp_date,stock_date,stock_time,qty) VALUES ('"+bcode+"','"+pname+"','"+xp+"','"+sqldate+"','"+sqltime+"','"+qty+"')");
            JOptionPane.showMessageDialog(null, "Data Saved");

        } catch (SQLException e) {
            System.out.println(e);
        }

        // update Stock

        int newqty =Integer.valueOf( txt_newqty.getText());
        int oldqty = Integer.valueOf(txt_qty.getText());

        int up_qty = newqty+  oldqty ;

        try {

            Statement s = db.mycon().createStatement();
            s.executeUpdate(" UPDATE product SET Qty ='"+up_qty+"'  WHERE pid = '"+id+"' ");

            JOptionPane.showMessageDialog(null, "Data Updated");

        } catch (Exception e) {
            System.out.println(e);
        }

        stock_load();
    }//GEN-LAST:event_saveActionPerformed

    private void txt_newqtyKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_newqtyKeyReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_newqtyKeyReleased

    private void txt_newqtyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_newqtyActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_newqtyActionPerformed

    private void txt_qtyKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_qtyKeyReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_qtyKeyReleased

    private void txt_qtyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_qtyActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_qtyActionPerformed

    private void txt_brKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_brKeyReleased
        // load unit price

        String  name =txt_br.getText();
        try {

            Statement s = db.mycon().createStatement();
            ResultSet rs = s.executeQuery("SELECT * FROM product WHERE bar_code ='"+name+"'  ");
            if (rs.next()) {

                id = rs.getString("pid");
                txt_pname.setText(rs.getString("Product_Name"));
                txt_qty.setText(rs.getString("Qty"));

            }

        } catch (SQLException e) {
            System.out.println(e);
        }
    }//GEN-LAST:event_txt_brKeyReleased

    private void txt_brActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_brActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_brActionPerformed

    private void lowstckActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_lowstckActionPerformed

        try {

            DefaultTableModel dt = (DefaultTableModel) pro_list.getModel();
            dt.setRowCount(0);
            Statement s = db.mycon().createStatement();

            ResultSet rs = s.executeQuery("SELECT * FROM product WHERE qty < 10  ");

            while (rs.next()) {
                Vector v = new Vector();

                v.add(rs.getString(1));
                v.add(rs.getString(2));
                v.add(rs.getString(3));
                v.add(rs.getString(4));
                v.add(rs.getString(5));
                v.add(rs.getString(6));
                v.add(rs.getString(7));
                v.add(rs.getString(8));
                v.add(rs.getString(9));

                dt.addRow(v);

            }

        } catch (Exception e) {
            tb_load();

        }
    }//GEN-LAST:event_lowstckActionPerformed

    private void p_search_tblKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_p_search_tblKeyReleased

        String name = p_search_tbl.getText();
        try {

            DefaultTableModel dt = (DefaultTableModel) pro_list.getModel();
            dt.setRowCount(0);
            Statement s = db.mycon().createStatement();

            ResultSet rs = s.executeQuery("SELECT * FROM product WHERE Product_Name LIKE '%"+name+"%' ");

            while (rs.next()) {
                Vector v = new Vector();

                v.add(rs.getString(1));
                v.add(rs.getString(2));
                v.add(rs.getString(3));
                v.add(rs.getString(4));
                v.add(rs.getString(5));
                v.add(rs.getString(6));
                v.add(rs.getString(7));
                v.add(rs.getString(8));
                v.add(rs.getString(9));

                dt.addRow(v);

            }

        } catch (Exception e) {
            tb_load();

        }
    }//GEN-LAST:event_p_search_tblKeyReleased

    private void p_search_tblActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_p_search_tblActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_p_search_tblActionPerformed

    private void pro_listKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_pro_listKeyPressed
        DefaultTableModel dt = (DefaultTableModel) pro_list.getModel();  
      
        int r = pro_list.getSelectedRow();

        String id  = pro_list.getValueAt(r, 0).toString();
        String name  = pro_list.getValueAt(r, 1).toString();
        String cat = pro_list.getValueAt(r, 2).toString();
        String bcode  = pro_list.getValueAt(r, 3).toString();
        String price  = pro_list.getValueAt(r, 4).toString();
        String sprice  = pro_list.getValueAt(r, 5).toString();
        String qty  = pro_list.getValueAt(r, 6).toString();
        String sid  = pro_list.getValueAt(r, 7).toString();
        String sname = pro_list.getValueAt(r, 8).toString();
        

        p_search.setText(id);
        p_name.setText(name);
        p_cat.setSelectedItem(cat);
        p_bcode.setText(bcode);
        p_cprice.setText(price);
        p_sprice.setText(sprice);
        p_qty.setText(qty);
        p_sid.setText(sid);
        com_sup.setSelectedItem(sname);
        
        try{
          Statement s = db.mycon().createStatement();
          ResultSet rs = s.executeQuery("select sum(qty) from cart where bar_code ='"+dt.getValueAt(r, 1).toString()+"'");
          
        while(rs.next()){
            lbl_tot_selled.setText(""+rs.getInt(1));
            }
        
            }catch (SQLException e){
                System.out.println(e);
            }
    }//GEN-LAST:event_pro_listKeyPressed

    private void pro_listMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pro_listMouseClicked
        DefaultTableModel dt = (DefaultTableModel) pro_list.getModel();  
      
        int r = pro_list.getSelectedRow();

        String id  = pro_list.getValueAt(r, 0).toString();
        String name  = pro_list.getValueAt(r, 1).toString();
        String cat = pro_list.getValueAt(r, 2).toString();
        String bcode  = pro_list.getValueAt(r, 3).toString();
        String price  = pro_list.getValueAt(r, 4).toString();
        String sprice  = pro_list.getValueAt(r, 5).toString();
        String qty  = pro_list.getValueAt(r, 6).toString();
        String sid  = pro_list.getValueAt(r, 7).toString();
        String sname = pro_list.getValueAt(r, 8).toString();
        

        p_search.setText(id);
        p_name.setText(name);
        p_cat.setSelectedItem(cat);
        p_bcode.setText(bcode);
        p_cprice.setText(price);
        p_sprice.setText(sprice);
        p_qty.setText(qty);
        p_sid.setText(sid);
        com_sup.setSelectedItem(sname);
        
        try{
          Statement s = db.mycon().createStatement();
          ResultSet rs = s.executeQuery("select sum(qty) from cart where product_name ='"+dt.getValueAt(r, 1).toString()+"'");
          
        while(rs.next()){
            lbl_tot_selled.setText(""+rs.getInt(1));
            }
        
            }catch (SQLException e){
                System.out.println(e);
            }
    }//GEN-LAST:event_pro_listMouseClicked

    private void com_supActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_com_supActionPerformed

        try {
            Statement s = db.mycon().createStatement();
            ResultSet rs = s.executeQuery(("SELECT * FROM supplier WHERE supplier_Name = '"+ com_sup.getSelectedItem().toString()+"' "));
            if(rs.next()){

                p_sid.setText(rs.getString("sid"));

            }

        } catch (SQLException e) {

            System.out.println(e);
        }
    }//GEN-LAST:event_com_supActionPerformed

    private void p_sidActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_p_sidActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_p_sidActionPerformed

    private void p_qtyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_p_qtyActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_p_qtyActionPerformed

    private void p_cpriceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_p_cpriceActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_p_cpriceActionPerformed

    private void p_spriceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_p_spriceActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_p_spriceActionPerformed

    private void delete_btnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_delete_btnActionPerformed
        // delete btn code
        
        int reply = JOptionPane.showConfirmDialog(null, "Are you sure you want to delete this product?", "Warning", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
        if (reply == JOptionPane.YES_OPTION) {
        String id = p_search.getText();

        try {
            Statement s = db.mycon().createStatement();
            s.executeUpdate("DELETE FROM product WHERE pid = '"+id+"' ");
            JOptionPane.showMessageDialog(null, "Data Deleted");

        } catch (HeadlessException | SQLException e) {
            System.out.println(e);
        }

        tb_load();
        } 
        else {
        
        }

        
    }//GEN-LAST:event_delete_btnActionPerformed

    private void update_btnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_update_btnActionPerformed
        // update btn code
        
        int reply = JOptionPane.showConfirmDialog(null, "Are you sure you want to update this product?", "Warning", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
        if (reply == JOptionPane.YES_OPTION) {
        
            
        String id =p_search.getText();
        String cat = p_cat.getSelectedItem().toString();
        String name = p_name.getText();
        String bcode = p_bcode.getText();
        String price = p_cprice.getText();
        String sprice = p_sprice.getText();
        String qty = p_qty.getText();
        String sid = p_sid.getText();
        String sname = com_sup.getSelectedItem().toString();

        try {

            Statement s = db.mycon().createStatement();

            //  Full texts 	pid 	Product_Name 	Bar_code 	Price 	Qty 	Sid

            s.executeUpdate("UPDATE product SET Product_Name='"+name+"',Prod_Category='"+cat+"' ,Bar_code='"+bcode+"' ,Price='"+price+"',sell_price='"+sprice+"',Qty='"+qty+"',Sid='"+sid+"',supplier_name='"+sname+"' WHERE pid ='"+id+"' ");

            JOptionPane.showMessageDialog(null, "Data Updated");

        } catch (Exception e) {
        }

        tb_load();
        }
        else{
        }

        
    }//GEN-LAST:event_update_btnActionPerformed

    private void save_btnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_save_btnActionPerformed
        // save product
        
        //String pr_id = p_search.getText();
        String name = p_name.getText();
        String bcode = p_bcode.getText();
        String cat = p_cat.getSelectedItem().toString();
        String price = p_cprice.getText();
        String sprice = p_sprice.getText();
        String qty = p_qty.getText();
        String sid = p_sid.getText();
        String sname = com_sup.getSelectedItem().toString();  //p_sname.getText();
        
        if (name.equals("")){
           JOptionPane.showMessageDialog(null, "Product name is empty."); 
        }
        else if (bcode.equals("")){
           JOptionPane.showMessageDialog(null, "Barcode is empty.");  
        }
        else if (price.equals("")){
           JOptionPane.showMessageDialog(null, "Costing Price is empty."); 
        }
        else if (sprice.equals("")){
           JOptionPane.showMessageDialog(null, "Selling Price is empty."); 
        }
        else{
        
            
        try {
            
            
            Statement s = db.mycon().createStatement();
            ResultSet rs = s.executeQuery(("SELECT * FROM product WHERE product_name = '"+name+"' "));
            if (rs.next()){
                JOptionPane.showMessageDialog(null, "Data already exist.");
            }
            else{
                // `pid`, `Product_Name`, `Bar_code`, `Price`, `Qty`, `Sid`
                s.executeUpdate("INSERT INTO product (Product_Name,Prod_Category,Bar_code,Price,sell_price,Qty,Sid,supplier_name) VALUES ('"+name+"','"+cat+"','"+bcode+"','"+price+"','"+sprice+"','"+qty+"','"+sid+"','"+sname+"')");
                //s.executeUpdate("IF NOT EXISTS (Select Product_Name From product where Product_Name = @Product_Name ) INSERT INTO product (Product_Name,Prod_Category,Bar_code,Price,sell_price,Qty,Sid,supplier_name) VALUES ('"+name+"','"+cat+"','"+bcode+"','"+price+"','"+sprice+"','"+qty+"','"+sid+"','"+sname+"')");
            
            JOptionPane.showMessageDialog(null, "Data Saved");
            }
            

        } catch (SQLException e) {
            System.out.println(e);
        }

        tb_load();
        }
    }//GEN-LAST:event_save_btnActionPerformed

    private void p_bcodeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_p_bcodeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_p_bcodeActionPerformed

    private void jTabbedPane1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTabbedPane1KeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTabbedPane1KeyPressed

    private void p_catActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_p_catActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_p_catActionPerformed

    private void p_nameFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_p_nameFocusGained
            /*if(p_name.getText().equals(" Name of Product...")){   //Clear text when focus gained             
            p_name.setText(""); 
            p_name.setForeground(new Color(0,0,0));             
            p_name.setFont(new Font("Tahoma",Font.PLAIN,14));
            
            }*/

    }//GEN-LAST:event_p_nameFocusGained

    private void p_nameFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_p_nameFocusLost
       /* if(p_name.getText().equals("")){          //Set text Search... when focus lost             
            p_name.setText(" Name of Product..."); 
            p_name.setForeground(new Color(153,153,153)); 
            p_name.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 14)); 
         
        } */

    }//GEN-LAST:event_p_nameFocusLost

    private void p_nameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_p_nameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_p_nameActionPerformed

    private void txt_pnameKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_pnameKeyReleased
        // load unit price

        String  name =txt_pname.getText();
        try {

            Statement s = db.mycon().createStatement();
            ResultSet rs = s.executeQuery("SELECT * FROM product WHERE product_name ='"+name+"'  ");
            if (rs.next()) {

                id = rs.getString("pid");
                txt_br.setText(rs.getString("bar_code"));
                txt_qty.setText(rs.getString("Qty"));

            }

        } catch (SQLException e) {
            System.out.println(e);
        }
    }//GEN-LAST:event_txt_pnameKeyReleased

  
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton add;
    private javax.swing.JButton add1;
    private javax.swing.JTable cat_tbl;
    private javax.swing.JLabel catid;
    private javax.swing.JComboBox<String> com_sup;
    private javax.swing.JButton delete;
    private javax.swing.JButton delete_btn;
    private de.wannawork.jcalendar.JCalendarPanel jCalendarPanel1;
    private com.toedter.calendar.JDateChooser jDateChooser1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private de.wannawork.jcalendar.JMonthPanel jMonthPanel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JLabel lbl_tot_selled;
    private javax.swing.JButton lowstck;
    private javax.swing.JTextField p_bcode;
    private javax.swing.JComboBox<String> p_cat;
    private javax.swing.JTextField p_cprice;
    public javax.swing.JTextField p_name;
    private javax.swing.JTextField p_qty;
    private javax.swing.JTextField p_search;
    private javax.swing.JTextField p_search_tbl;
    private javax.swing.JTextField p_sid;
    private javax.swing.JTextField p_sprice;
    private javax.swing.JTable pro_list;
    private javax.swing.JButton save;
    private javax.swing.JButton save_btn;
    private datechooser.demo.steps.Show4Permanent show4Permanent1;
    private javax.swing.JTable stk_tbl;
    private javax.swing.JTextField txt_br;
    private javax.swing.JTextField txt_cat;
    private javax.swing.JTextField txt_newqty;
    private javax.swing.JTextField txt_pname;
    private javax.swing.JTextField txt_qty;
    private javax.swing.JButton update_btn;
    private com.toedter.calendar.JDateChooser xpdate;
    // End of variables declaration//GEN-END:variables
}
